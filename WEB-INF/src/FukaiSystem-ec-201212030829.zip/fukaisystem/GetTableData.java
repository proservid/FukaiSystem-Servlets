﻿package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.GetTableDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class GetTableData extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetTableData\n";


	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		GetTableDTO input = null;
		StringBuilder err = new StringBuilder("");
		Map<String, List<String>> data = new HashMap<String, List<String>>();
//		List<List<String>> data = new ArrayList<List<String>>();

		try {

			/**
			 * クライアントデータ受け取り
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append("readObjectがnullです\n");
				lg.error(className + "readObjectがnullです");
			} else {
				if(obj instanceof GetTableDTO) {
					input = (GetTableDTO)obj;
				} else {
					err.append("readObjectがString型ではありません\n");
					lg.error(className + "readObjectがString型ではありません");
				}
			}

			try {
//				int columns = 0;
//				ps = c.prepareStatement("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME=?");
//				ps.setString(1, input.get(0));
//				rs = ps.executeQuery();
//				if(rs.next()) {
//					columns = rs.getInt(1);
//					for(int i = 0; i < columns; i++) {
//						List<String> al = new ArrayList<String>();
//						data.add(al);
//					}
//				}
				System.out.println("SELECT " + input.get(1) + " FROM " + input.get(0) + " WHERE " + input.get(2) + "=?");
				ps = c.prepareStatement("SELECT " + input.get(1) + " FROM " + input.get(0) + " WHERE " + input.get(2) + "=?");
				ps.setString(1, input.get(3));System.out.println(input.get(3));
				rs = ps.executeQuery();
				ResultSetMetaData metaData = rs.getMetaData();
				int columnCount = metaData.getColumnCount();

				while(rs.next()) {
					for (int i = 0; i < columnCount; i++) {
						String columnName = metaData.getColumnName(i + 1);
						if(data.containsKey(columnName)) data.get(columnName).add(rs.getString(columnName));
						else {
							List<String> columnData = new ArrayList<String>();
							columnData.add(rs.getString(columnName));System.out.println(rs.getString(columnName));
							data.put(columnName, columnData);
						}
					}
				}
			} catch(SQLException ex) {
				err.append("テーブル「T_テーブル名」の読込に失敗しました\n");
				Logging.logStackTrace(ex, lg, className);
			}

		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * クライアントに送信
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(data);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
