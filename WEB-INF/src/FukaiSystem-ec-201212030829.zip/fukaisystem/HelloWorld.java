﻿package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;




import org.apache.log4j.Logger;

import fukaisystem.dto.InitialDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;

public class HelloWorld extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
    private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "HelloWorld\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;

		List<String> slips = new ArrayList<String>();
		Map<Integer, String> types = new LinkedHashMap<Integer, String>();
		Map<Integer, String> routes = new HashMap<Integer, String>();
		Map<Integer, String> terms = new HashMap<Integer, String>();
		Map<Integer, String> submits = new HashMap<Integer, String>();
		Map<Integer, String> currencies = new HashMap<Integer, String>();
		Map<Integer, String> states = new HashMap<Integer, String>();
		Map<Integer, String> ways = new HashMap<Integer, String>();
		Map<Integer, String> indication = new HashMap<Integer, String>();
		Map<Integer, String> units = new HashMap<Integer, String>();
		Map<Integer, Integer> works = new HashMap<Integer, Integer>();
		Map<Integer, String> categoryL = new LinkedHashMap<Integer, String>();
		Map<List<Integer>, Map<Integer, String>> categoryM = new HashMap<List<Integer>, Map<Integer, String>>();
		Map<List<Integer>, Map<Integer, String>> categoryS = new HashMap<List<Integer>, Map<Integer, String>>();

		try {

			/**
			 * クライアントデータ受け取り
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();
			System.out.println("obj:"+obj);
			try {
				ps = c.prepareStatement("SELECT 帳票名 FROM T_帳票");
				rs = ps.executeQuery();
				while(rs.next()) {
					slips.add(rs.getString("帳票名"));
				}

				ps = c.prepareStatement("SELECT * FROM M_製品種別");
				rs = ps.executeQuery();
				while(rs.next()) {
					types.put(rs.getInt("CD"), rs.getString("製品種別"));
				}

				ps = c.prepareStatement("SELECT * FROM M_依頼手段");
				rs = ps.executeQuery();
				while(rs.next()) {
					routes.put(rs.getInt("CD"), rs.getString("依頼手段"));
				}

				ps = c.prepareStatement("SELECT * FROM M_取引条件");
				rs = ps.executeQuery();
				while(rs.next()) {
					terms.put(rs.getInt("CD"), rs.getString("取引条件"));
				}

				ps = c.prepareStatement("SELECT * FROM M_見積提出");
				rs = ps.executeQuery();
				while(rs.next()) {
					submits.put(rs.getInt("CD"), rs.getString("見積提出"));
				}

				ps = c.prepareStatement("SELECT * FROM M_使用通貨");
				rs = ps.executeQuery();
				while(rs.next()) {
					currencies.put(rs.getInt("CD"), rs.getString("通貨記号"));
				}

				ps = c.prepareStatement("SELECT * FROM M_納入状況");
				rs = ps.executeQuery();
				while(rs.next()) {
					states.put(rs.getInt("CD"), rs.getString("納入状況"));
				}

				ps = c.prepareStatement("SELECT * FROM M_納入手段");
				rs = ps.executeQuery();
				while(rs.next()) {
					ways.put(rs.getInt("CD"), rs.getString("納入手段"));
				}

				ps = c.prepareStatement("SELECT * FROM M_見積表示");
				rs = ps.executeQuery();
				while(rs.next()) {
					indication.put(rs.getInt("CD"), rs.getString("表示種別"));
				}

				ps = c.prepareStatement("SELECT * FROM M_数量単位");
				rs = ps.executeQuery();
				while(rs.next()) {
					units.put(rs.getInt("CD"), rs.getString("数量単位"));
				}

				ps = c.prepareStatement("SELECT * FROM M_加工");
				rs = ps.executeQuery();
				while(rs.next()) {
					works.put(rs.getInt("CD"), rs.getInt("単価"));
				}

				ps = c.prepareStatement("SELECT * FROM M_原価大分類");
				rs = ps.executeQuery();
				while(rs.next()) {
					categoryL.put(rs.getInt("CD"), rs.getString("大分類名"));
				}

				ps = c.prepareStatement("SELECT * FROM M_原価中分類");
				rs = ps.executeQuery();
				while(rs.next()) {
					List<Integer> subKey = new ArrayList<Integer>();
					subKey.add(rs.getInt("大分類CD"));
					if(!categoryM.containsKey(subKey)) {
						categoryM.put(subKey, new LinkedHashMap<Integer, String>());
					}
					categoryM.get(subKey).put(rs.getInt("CD"), rs.getString("中分類名"));
				}

			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}


			try {
				ps = c.prepareStatement("SELECT * FROM M_原価小分類");
				rs = ps.executeQuery();
				while(rs.next()) {
					List<Integer> subKey = new ArrayList<Integer>();
					subKey.add(rs.getInt("大分類CD"));
					subKey.add(rs.getInt("中分類CD"));
					if(!categoryS.containsKey(subKey)) {
						categoryS.put(subKey, new LinkedHashMap<Integer, String>());
					}
					categoryS.get(subKey).put(rs.getInt("CD"), rs.getString("小分類名"));
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}



			/**
			 * クライアントに送信
			 */

			InitialDTO id = new InitialDTO(slips, types, routes, terms, submits, currencies, states, ways, indication, units, works, categoryL, categoryM, categoryS);
System.out.println(id);
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(id);
			out.writeUTF("acitve:"+dbc.getNumActive()+" idle:"+dbc.getNumIdle());
			out.flush();
			out.close();

		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
