﻿/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fukaisystem.dto;

import java.io.Serializable;


/**
 *
 * @author kameura
 */
public class ProjectSearchDTO implements Serializable {

	String accountName, projectName, number_eb, acceptID, number_pb, inquiry_y, inquiry_m, inquiry_d,
	 submit_y, submit_m, submit_d, accept_y, accept_m, accept_d, production_y, production_m, production_d,
	 due_y, due_m, due_d, delivery_y, delivery_m, delivery_d;
	int accountID, projectCode, period_e, number_e, price_e, orderCode, period_p, number_p, price_p, deliveryCode;
	boolean isAnd;

	public ProjectSearchDTO(int accountID, String accountName, String projectName, int projectCode,
	 int period_e, int number_e, String number_eb, String inquiry_y, String inquiry_m, String inquiry_d,
	 String submit_y, String submit_m, String submit_d, int price_e,
	 int orderCode, String acceptID, String accept_y, String accept_m, String accept_d, int period_p, int number_p, String number_pb,
	 String production_y, String production_m, String production_d, String due_y, String due_m, String due_d,
	 int price_p, int deliveryCode, String delivery_y, String delivery_m, String delivery_d,
	 boolean isAnd) {
		this.accountName = accountName;
		this.projectName = projectName;
		this.number_eb = number_eb;
		this.acceptID = acceptID;
		this.number_pb = number_pb;
		this.accountID = accountID;
		this.projectCode = projectCode;
		this.period_e = period_e;
		this.number_e = number_e;
		this.price_e = price_e;
		this.orderCode = orderCode;
		this.period_p = period_p;
		this.number_p = number_p;
		this.price_p = price_p;
		this.deliveryCode = deliveryCode;
		this.inquiry_y = inquiry_y;
		this.inquiry_m = inquiry_m;
		this.inquiry_d = inquiry_d;
		this.submit_y = submit_y;
		this.submit_m = submit_m;
		this.submit_d = submit_d;
		this.accept_y = accept_y;
		this.accept_m = accept_m;
		this.accept_d = accept_d;
		this.production_y = production_y;
		this.production_m = production_m;
		this.production_d = production_d;
		this.due_y = due_y;
		this.due_m = due_m;
		this.due_d = due_d;
		this.delivery_y = delivery_y;
		this.delivery_m = delivery_m;
		this.delivery_d = delivery_d;
		this.isAnd = isAnd;
	}

	public String getStr(int order) {
		String s = "";
		switch(order) {
			case  0: s = accountName; break;
			case  1: s = projectName; break;
			case  2: s = number_eb; break;
			case  3: s = acceptID; break;
			case  4: s = number_pb; break;
			case  5: s = inquiry_y; break;
			case  6: s = inquiry_m; break;
			case  7: s = inquiry_d; break;
			case  8: s = submit_y; break;
			case  9: s = submit_m; break;
			case 10: s = submit_d; break;
			case 11: s = accept_y; break;
			case 12: s = accept_m; break;
			case 13: s = accept_d; break;
			case 14: s = production_y; break;
			case 15: s = production_m; break;
			case 16: s = production_d; break;
			case 17: s = due_y; break;
			case 18: s = due_m; break;
			case 19: s = due_d; break;
			case 20: s = delivery_y; break;
			case 21: s = delivery_m; break;
			case 22: s = delivery_d; break;
		}
		return s;
	}

	public int getInt(int order) {
		int i = 0;
		switch(order) {
			case 0:	i = accountID; break;
			case 1:	i = projectCode; break;
			case 2:	i = period_e; break;
			case 3:	i = number_e; break;
			case 4:	i = price_e; break;
			case 5:	i = orderCode; break;
			case 6:	i = period_p; break;
			case 7:	i = number_p; break;
			case 8:	i = price_p; break;
			case 9:	i = deliveryCode; break;
		}
		return i;
	}

	public boolean isAnd() {
		return isAnd;
	}
}
