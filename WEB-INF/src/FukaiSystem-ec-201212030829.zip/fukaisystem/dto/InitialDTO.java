﻿/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fukaisystem.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 *
 * @author kameura
 */
public class InitialDTO implements Serializable {

	List<String> slips;
	Map<Integer, String> types;
	Map<Integer, String> routes;
	Map<Integer, String> terms;
	Map<Integer, String> submits;
	Map<Integer, String> currencies;
	Map<Integer, String> states;
	Map<Integer, String> ways;
	Map<Integer, String> indication;
	Map<Integer, String> units;
	Map<Integer, Integer> works;
	Map<Integer, String> categoryL;
	Map<List<Integer>, Map<Integer, String>> categoryM;
	Map<List<Integer>, Map<Integer, String>> categoryS;

	public InitialDTO(
	List<String> slips,
	 Map<Integer, String> types,
	 Map<Integer, String> routes,
	 Map<Integer, String> terms,
	 Map<Integer, String> submits,
	 Map<Integer, String> currencies,
	 Map<Integer, String> states,
	 Map<Integer, String> ways,
	 Map<Integer, String> indication,
	 Map<Integer, String> units,
	 Map<Integer, Integer> works,
	 Map<Integer, String> categoryL,
	 Map<List<Integer>, Map<Integer, String>> categoryM,
	 Map<List<Integer>, Map<Integer, String>> categoryS) {
		this.slips = slips;
		this.types = types;
		this.routes = routes;
		this.terms = terms;
		this.submits = submits;
		this.currencies = currencies;
		this.states = states;
		this.ways = ways;
		this.indication = indication;
		this.units = units;
		this.works = works;
		this.categoryL = categoryL;
		this.categoryM = categoryM;
		this.categoryS = categoryS;
	}
	public List<String> getSlips() {
		return slips;
	}
	public Map<Integer, String> getTypes() {
		return types;
	}
	public Map<Integer, String> getRoutes() {
		return routes;
	}
	public Map<Integer, String> getTerms() {
		return terms;
	}
	public Map<Integer, String> getSubmits() {
		return submits;
	}
	public Map<Integer, String> getCurrencies() {
		return currencies;
	}
	public Map<Integer, String> getStates() {
		return states;
	}
	public Map<Integer, String> getWays() {
		return ways;
	}
	public Map<Integer, String> getIndication() {
		return indication;
	}
	public Map<Integer, String> getUnits() {
		return units;
	}
	public Map<Integer, Integer> getWorks() {
		return works;
	}
	public Map<Integer, String> getCategoryL() {
		return categoryL;
	}
	public Map<List<Integer>, Map<Integer, String>> getCategoryM() {
		return categoryM;
	}
	public Map<List<Integer>, Map<Integer, String>> getCategoryS() {
		return categoryS;
	}
}
