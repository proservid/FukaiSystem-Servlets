/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fukaisystem.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kameura
 */
public class GetTableDTO implements Serializable {
	String tableName;
	String columnName;
	String condition;
	String id;

	public GetTableDTO(String tableName, String columnName, String condition, String id) {
		this.tableName = tableName;
		this.columnName = columnName;
		this.condition = condition;
		this.id = id;
	}
	public String get(int i) {
		String s = "";
		switch(i) {
			case 0 : s = tableName;break;
			case 1 : s = columnName;break;
			case 2 : s = condition;break;
			case 3 : s = id;break;
		}
		return s;
	}
}
