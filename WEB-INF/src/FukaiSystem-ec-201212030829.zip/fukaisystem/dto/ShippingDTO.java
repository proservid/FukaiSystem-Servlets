/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fukaisystem.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Vector;

/**
 *
 * @author kameura
 */
public class ShippingDTO implements Serializable {
	Date issue, shipping;
	int shippingID, productID, slipID, way;
	boolean isPartial;
	Vector<Vector<Object>> vector;

	public ShippingDTO(int shippingID, int productID, int slipID, int way, boolean isPartial, Date issue, Date shipping, Vector<Vector<Object>> vector) {
		this.shippingID = shippingID;
		this.productID = productID;
		this.slipID = slipID;
		this.way = way;
		this.isPartial = isPartial;
		this.issue = issue;
		this.shipping = shipping;
		this.vector = vector;
	}

	public int getInt(int order) {
		int i = 0;
		switch(order) {
			case 0:
				i = shippingID; break;
			case 1:
				i = productID; break;
			case 2:
				i = slipID; break;
			case 3:
				i = way; break;
		}
		return i;
	}
	public boolean getBool() {
		return isPartial;
	}
	public Date getDate(int order) {
		Date d = null;
		switch(order) {
			case 0:
				d = issue; break;
			case 1:
				d = shipping; break;
		}
		return d;
	}
	public Vector<Vector<Object>> getVector() {
		return vector;
	}
}
