﻿/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fukaisystem.dto;

import java.sql.Date;
import java.util.Map;
import java.util.Vector;

/**
 *
 * @author kameura
 */
public class ProjectSummaryDTO extends BasicDTO {

	 String accountName, projectName, projectQuantity,
	  number_eb, deadline, place, terms, validity, note_e,
	  acceptID, number_pb, note_p,
	  note_d;
	 int accountID, projectCode,
	  estimateID, period_e, number_e, contactCode, inquiryCode,
	  submitCD, currencyCD, amount_e,
	  productID, period_p, number_p, amount_p,
	  deliveryState, deliveryCode;
	 Date inquiryDate, estimateDate, submitDate,
	  acceptDate, dueDate, publishDate,
	  shippingDate, inspectionDate;
	 boolean isRelease, isOrder;
	 Vector<Vector<Object>> mainTable_e, mainTable_p;
	 Map<Integer, Vector<Vector<Object>>> subTable_e, subTable_p;

	public ProjectSummaryDTO(
	 //共通
	 String accountName, String projectName, String projectQuantity,
	 int accountID, int projectCode,
	 //見積
	 String number_eb, String deadline, String place, String terms, String validity, String note_e,
	 int estimateID, int period_e, int number_e, int contactCode, int inquiryCode,
	 int submitCD, int currencyCD, int amount_e,
	 Date inquiryDate, Date estimateDate, Date submitDate,
	 Vector<Vector<Object>> mainTable_e,
	 Map<Integer, Vector<Vector<Object>>> subTable_e,
	 //製作
	 String acceptID, String number_pb, String note_p,
	 int productID, int period_p, int number_p, int amount_p,
	 Date acceptDate, Date dueDate, Date productionDate,
	 boolean isRelease, boolean isOrder,
	 Vector<Vector<Object>> mainTable_p,
	 Map<Integer, Vector<Vector<Object>>> subTable_p,
	 //出荷
	 String note_d,
	 int deliveryState, int deliveryCode,
	 Date shippingDate, Date inspectionDate) {
		this.accountName = accountName;	this.projectName = projectName;	this.projectQuantity = projectQuantity;
		this.accountID = accountID;	this.projectCode = projectCode;
		this.number_eb = number_eb; this.deadline = deadline;	this.place = place;	this.terms = terms;	this.validity = validity; this.note_e = note_e;
		this.estimateID = estimateID; this.period_e = period_e; this.number_e = number_e; this.contactCode = contactCode;	this.inquiryCode = inquiryCode;
		this.submitCD = submitCD; this.currencyCD = currencyCD; this.amount_e = amount_e;
		this.inquiryDate = inquiryDate;	this.estimateDate = estimateDate; this.submitDate = submitDate;
		this.mainTable_e = mainTable_e;
		this.subTable_e = subTable_e;

		this.acceptID = acceptID; this.number_pb = number_pb; this.note_p = note_p;
		this.productID = productID; this.period_p = period_p; this.number_p = number_p; this.amount_p = amount_p;
		this.acceptDate = acceptDate; this.dueDate = dueDate; this.publishDate = productionDate;
		this.isRelease = isRelease;	this.isOrder = isOrder;
		this.mainTable_p = mainTable_p;
		this.subTable_p = subTable_p;

		this.note_d = note_d;
		this.deliveryState = deliveryState;	this.deliveryCode = deliveryCode;
		this.shippingDate = shippingDate;
		this.inspectionDate = inspectionDate;
	}

	@Override
	public String getStr(int order) {
		String s = "";
		switch(order) {
			case  0: s = accountName; break;
			case  1: s = projectName; break;
			case  2: s = projectQuantity; break;
			case  3: s = number_eb; break;
			case  4: s = deadline; break;
			case  5: s = place; break;
			case  6: s = terms; break;
			case  7: s = validity; break;
			case  8: s = note_e; break;
			case  9: s = acceptID; break;
			case 10: s = number_pb; break;
			case 11: s = note_p; break;
			case 12: s = note_d; break;
		}
		return s;
	}

	@Override
	public int getInt(int order) {
		int i = 0;
		switch(order) {
			case  0: i = accountID; break;
			case  1: i = projectCode; break;
			case  2: i = period_e; break;
			case  3: i = number_e; break;
			case  4: i = contactCode; break;
			case  5: i = inquiryCode; break;
			case  6: i = submitCD; break;
			case  7: i = currencyCD; break;
			case  8: i = amount_e; break;
			case  9: i = period_p; break;
			case 10: i = number_p; break;
			case 11: i = amount_p; break;
			case 12: i = deliveryState; break;
			case 13: i = deliveryCode; break;
			case 14: i = estimateID; break;
			case 15: i = productID; break;

		}
		return i;
	}

	@Override
	public Date getDate(int order) {
		Date d = null;
		switch(order) {
			case 0: d = inquiryDate; break;
			case 1: d = estimateDate; break;
			case 2: d = submitDate; break;
			case 3: d = acceptDate; break;//受注年月日
			case 4: d = dueDate; break;//納期
			case 5: d = publishDate; break;//発行年月日
			case 6: d = shippingDate; break;//出荷年月日
			case 7: d = inspectionDate; break;//検収年月日

		}
		return d;
	}

	@Override
	public boolean getBool(int order) {
		boolean b = false;
		switch(order) {
			case 0: b = isRelease; break;
			case 1: b = isOrder; break;
		}
		return b;
	}

	@Override
	public Vector<Vector<Object>> getVector(int order) {
		Vector<Vector<Object>> v = null;
		switch(order) {
			case 0: v = mainTable_e; break;
			case 1: v = mainTable_p; break;
		}
		return v;
	}
	public void setVector(int order, Vector<Vector<Object>> vector) {
		switch(order) {
			case 0: mainTable_e = vector; break;
			case 1: mainTable_p = vector; break;
		}
	}

	public Map<Integer, Vector<Vector<Object>>> getMap(int order) {
		Map<Integer, Vector<Vector<Object>>> m = null;
		switch(order) {
			case 0: m = subTable_e; break;
			case 1: m = subTable_p; break;
		}
		return m;
	}
	public void setMap(int order, Map<Integer, Vector<Vector<Object>>> map) {
		switch(order) {
			case 0: subTable_e = map; break;
			case 1: subTable_p = map; break;
		}
	}

}
