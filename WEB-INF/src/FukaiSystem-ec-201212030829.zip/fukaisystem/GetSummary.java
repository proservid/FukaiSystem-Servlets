﻿package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


import org.apache.log4j.Logger;

import fukaisystem.dto.ProjectSummaryDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class GetSummary extends GenericServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetSummary\n";

	@Override
	public void service(ServletRequest request, ServletResponse response) {
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		ProjectSummaryDTO psDTO = null;
		StringBuilder err = new StringBuilder();

		int estimateID = 0, productID = 0;

		Vector<Vector<Object>> estimateData = new Vector<Vector<Object>>();
		Vector<Vector<Object>> productData = new Vector<Vector<Object>>();
		Map<Integer, Vector<Vector<Object>>> map = new HashMap<Integer, Vector<Vector<Object>>>();

		try {

			/**
			 * クライアントデータ受け取り
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObjectがnullです\n");
				lg.error(className + "readObjectがnullです");
			} else {
				if(obj instanceof Number) {
					estimateID = ((Number)obj).intValue();
				} else {
					System.out.println("estID:"+obj);
					err.append(className + "readObjectがSetSummaryDTO型ではありません\n");
					lg.error(className + "readObjectがSetSummaryDTO型ではありません");
				}
			}
			try {
				StringBuilder query = new StringBuilder(
				 "SELECT" +
				 " 会社名,e.案件名 AS 案件名e,数量等,e.得意先CD,種類,見積枝番,e.納期 AS 納期e,受渡場所,取引条件CD,有効期間,e.備考 AS 備考e," +
				 " e.見積親ID,見積期,見積番号,個人CD,依頼手段CD,提出済CD,通貨CD,見積金額,依頼年月日," +
				 " 見積年月日,提出年月日,受注番号,製作枝番,p.備考 AS 備考p,製作親ID,製作期,製作番号,契約金額," +
				 " 受注年月日,p.納期 AS 納期p,発行年月日,出図FLG,手配FLG,納品備考,納品状況CD,納品手段CD,出荷年月日,検収年月日" +
				 " FROM T_見積_親 e" +
				 " LEFT OUTER JOIN (" +
				 "	SELECT 得意先CD,会社名 FROM M_内国法人" +
				 "	UNION ALL" +
				 "	SELECT 得意先CD,会社名 FROM M_外国法人" +
				 " ) c" +
				 " ON e.得意先CD=c.得意先CD" +
				 " FULL OUTER JOIN T_製作_親 p" +
				 " ON e.見積親ID=p.見積親ID" +
				 " WHERE e.見積親ID=?");
				ps = c.prepareStatement(query.toString());
				ps.setInt(1, estimateID);
				System.out.println("estID:"+estimateID);
				rs = ps.executeQuery();
				while(rs.next()) {
					productID = rs.getInt("製作親ID");
					psDTO = new ProjectSummaryDTO(
					 //共通
					 rs.getString("会社名"), rs.getString("案件名e"), rs.getString("数量等"),
					 rs.getInt("得意先CD"), rs.getInt("種類"),
					 //見積
					 rs.getString("見積枝番"), rs.getString("納期e"), rs.getString("受渡場所"), rs.getString("取引条件CD"), rs.getString("有効期間"), rs.getString("備考e"),
					 estimateID, rs.getInt("見積期"), rs.getInt("見積番号"), rs.getInt("個人CD"), rs.getInt("依頼手段CD"),
					 rs.getInt("提出済CD"), rs.getInt("通貨CD"), rs.getInt("見積金額"),
					 rs.getDate("依頼年月日"), rs.getDate("見積年月日"), rs.getDate("提出年月日"),
					 null,//Vector<Vector<Object>> mainTable_e,
					 null,//Map<Integer, Vector<Vector<Object>>> subTable_e,
					 //製作
					 rs.getString("受注番号"), rs.getString("製作枝番"), rs.getString("備考p"),
					 productID, rs.getInt("製作期"), rs.getInt("製作番号"), rs.getInt("契約金額"),
					 rs.getDate("受注年月日"), rs.getDate("納期p"), rs.getDate("発行年月日"),
					 rs.getBoolean("出図FLG"), rs.getBoolean("手配FLG"),
					 null,//Vector<Vector<Object>> mainTable_p,
					 null,//Map<Integer, Vector<Vector<Object>>> subTable_p,
					 //出荷
					 rs.getString("納品備考"),
					 rs.getInt("納品状況CD"), rs.getInt("納品手段CD"),
					 rs.getDate("出荷年月日"), rs.getDate("検収年月日"));
				}

				ps = c.prepareStatement("SELECT * FROM T_見積_子 WHERE 見積親ID=?");
				ps.setInt(1, estimateID);
				rs = ps.executeQuery();
				while(rs.next()) {
					int serial = rs.getInt("ID");
					Vector<Object> line = new Vector<Object>();
					line.add(serial);
					line.add(rs.getInt("表示CD"));
					line.add(rs.getString("名称"));
					line.add(rs.getBoolean("各FLG"));
					line.add(rs.getInt("数量"));
					line.add(rs.getInt("数量単位CD"));
					line.add(rs.getInt("提示額"));
					line.add(rs.getString("図番"));
					line.add(rs.getString("備考"));
					estimateData.add(line);
				}

				ps = c.prepareStatement(
				 "SELECT ID,見積子ID,見積親ID,大分類CD,中分類CD,小分類CD,名称,単価,数量,ROUND(単価*数量,0) AS 原価,掛率,ROUND(単価*数量*掛率,0) AS 小計,品番,重量,仕入先CD,仕入見積FLG,仕入納期,備考" +
				 " FROM T_見積_材料 WHERE 見積親ID=?" +
				 " UNION ALL" +
				 " SELECT ID,見積子ID,見積親ID,大分類CD,加工CD,0,'',単価,時間,ROUND(単価*時間,0) AS 原価,掛率,ROUND(単価*時間*掛率,0) AS 小計,0,0,0,'false','',備考" +
				 " FROM T_見積_加工" +
				 "  WHERE 見積親ID=? ORDER BY 見積子ID");
				ps.setInt(1, estimateID);
				ps.setInt(2, estimateID);
				rs = ps.executeQuery();
				while(rs.next()) {
					Vector<Object> line = new Vector<Object>();
					line.add(rs.getInt("ID"));
					int id = rs.getInt("見積子ID");
					line.add(rs.getInt("大分類CD"));
					line.add(rs.getInt("中分類CD"));
					line.add(rs.getInt("小分類CD"));
					line.add(rs.getString("名称"));
					line.add(rs.getInt("単価"));
					line.add(rs.getFloat("数量"));
					line.add(rs.getInt("原価"));//計算
					line.add(rs.getFloat("掛率"));
					line.add(rs.getInt("小計"));//計算
					line.add(rs.getInt("品番"));
					line.add(rs.getInt("重量"));
					line.add(rs.getInt("仕入先CD"));
					line.add(rs.getBoolean("仕入見積FLG"));
					line.add(rs.getString("仕入納期"));
					line.add(rs.getString("備考"));
					if(map.containsKey(id)) {
						map.get(id).add(line);
					} else {
						Vector<Vector<Object>> data = new Vector<Vector<Object>>();
						data.add(line);
						map.put(id, data);
					}
				}

				psDTO.setVector(0, estimateData);
				psDTO.setMap(0, map);


			} catch(SQLException ex) {
				err.append(className + "DBエラーが発生しました\n");
				Logging.logStackTrace(ex, lg, className);
			}
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}
		try {
			ps = c.prepareStatement("SELECT * FROM T_製作_子 WHERE 製作親ID=?");
			ps.setInt(1, productID);
			rs = ps.executeQuery();
			while(rs.next()) {
				Vector<Object> line = new Vector<Object>();
				line.add(rs.getInt("表示CD"));
				line.add(rs.getString("名称"));
				line.add(rs.getBoolean("各FLG"));
				line.add(rs.getInt("数量"));
				line.add(rs.getInt("数量単位CD"));
				line.add(rs.getInt("提示額"));
				line.add(rs.getString("図番"));
				line.add(rs.getString("備考"));
				line.add(rs.getDate("完成年月日"));
				line.add(rs.getDate("完成年月日") != null);
				line.add(rs.getDate("納品年月日"));
				line.add(rs.getDate("納品年月日") != null);
				productData.add(line);
			}
			psDTO.setVector(1, productData);
		}catch(Exception ex) {
			err.append(ex.toString());
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * クライアントに送信
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(psDTO);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
