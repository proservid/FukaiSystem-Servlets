﻿package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.ProjectSearchDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;



public class Search extends GenericServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "Search\n";

	@Override
	public void service(ServletRequest request, ServletResponse response) {
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean isError = false;
		ProjectSearchDTO searchDTO = null;
		StringBuilder err = new StringBuilder();
		List<Integer> strIndex = new ArrayList<Integer>();
		List<Integer> intIndex = new ArrayList<Integer>();

		Vector<Vector<Object>> v = new Vector<Vector<Object>>();

		String[] constStrs = {"(e.案件名 LIKE ? OR p.案件名 LIKE ?)", "見積枝番=?", "受注番号=?", "製作枝番=?", "依頼年月日=?", "提出年月日=?", "受注年月日=?", "発行年月日=?", "p.納期=?", "出荷年月日=?", "検収年月日=?"};
		String[] constInts = {"e.得意先CD=?", "種別=?", "見積期=?", "見積番号=?", "見積金額=?", "受注番号=?", "製作期=?", "製作番号=?", "契約金額=?", "納品状況CD=?"};
		try {

			/**
			 * クライアントデータ受け取り
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				isError = true;
				err.append(className + "readObjectがnullです\n");
				lg.error(className + "readObjectがnullです");
			} else {
				if(obj instanceof ProjectSearchDTO) {
					searchDTO = (ProjectSearchDTO)obj;
				} else {
					isError = true;
					err.append(className + "readObjectがProjectSearchDTO型ではありません\n");
					lg.error(className + "readObjectがProjectSearchDTO型ではありません");
				}
			}
			try {
				StringBuilder query = new StringBuilder(
				 "SELECT e.見積親ID,見積期,見積番号,見積枝番," +
				 " (CASE" +
				 "	WHEN p.案件名 IS NULL THEN e.案件名" +
				 "	ELSE p.案件名" +
				 " END) AS 案件名," +
				 " 種類,依頼年月日,提出年月日,e.得意先CD,製作期,製作番号," +
				 " 製作枝番,会社名,見積金額,受注番号,受注年月日,p.納期," +
				 " 発行年月日,契約金額,納品状況CD,出荷年月日,検収年月日" +
				 " FROM T_見積_親 e" +
				 " LEFT OUTER JOIN (" +
				 "	SELECT 得意先CD,会社名 FROM M_内国法人" +
				 "	UNION ALL" +
				 "	SELECT 得意先CD,会社名 FROM M_外国法人" +
				 " ) c" +
				 " ON e.得意先CD=c.得意先CD" +
				 " FULL OUTER JOIN T_製作_親 p" +
				 " ON e.見積親ID=p.見積親ID");
				boolean isFirst = true;
				//文字列の検索条件は、searchDTO.getStr(1～4)
				for(int i = 1; i < 5; i++) {System.out.println(i);
					if(!searchDTO.getStr(i).equals("")) {//検索条件が入っていれば
						strIndex.add(i);
						if(isFirst) {
							query.append(" WHERE ");
							isFirst = false;
						} else {
							if(searchDTO.isAnd()) query.append(" AND ");
							else query.append(" OR ");
						}
						query.append(constStrs[i - 1]);
					}
				}
				String y = "", m = "", d = "";
				//年月日の検索条件は、searchDTO.getStr(5～22)
				for(int i = 5; i < 23; i++) {
					int reminder = i % 3;
					if(reminder == 2) {
						y = searchDTO.getStr(i);
					} else if(reminder == 0) {
						m = searchDTO.getStr(i);
					} else if(reminder == 1) {
						d = searchDTO.getStr(i);
						if(!(y + m + d).equals("")) {
							boolean eachFlag = false;
							if(isFirst) {
								query.append(" WHERE ");
								isFirst = false;
							} else {
								if(searchDTO.isAnd()) query.append(" AND ");
								else query.append(" OR ");
							}

							if(!y.equals("") && !m.equals("")) {
								if(!d.equals("")) {//全部入り
									query.append(partialDateStr(constStrs[i / 3 + 2], y + "-" + m + "-" + d, 1, 10));
								} else {//ymのみ
									query.append(partialDateStr(constStrs[i / 3 + 2], y + "-" + m, 1, 7));
								}
							} else if(!m.equals("") && !d.equals("")) {
								query.append(partialDateStr(constStrs[i / 3 + 2], m + "-" + d, 6, 5));
							} else {
								if(!y.equals("")) {
									query.append(partialDateStr(constStrs[i / 3 + 2], y, 1, 4));
									eachFlag = true;
								}
								if(!m.equals("")) {
									if(eachFlag) {
										if(searchDTO.isAnd()) query.append(" AND ");
										else query.append(" OR ");
									}
									query.append(partialDateStr(constStrs[i / 3 + 2], m, 6, 2));
									eachFlag = true;
								}
								if(!d.equals("")) {
									if(eachFlag) {
										if(searchDTO.isAnd()) query.append(" AND ");
										else query.append(" OR ");
									}
									query.append(partialDateStr(constStrs[i / 3 + 2], d, 9, 2));
								}
							}
						}
					}
				}
				//数値の検索条件は、searchDTO.getInt(0～9)
				for(int i = 0; i < 10; i++) {
					if(searchDTO.getInt(i) != 0) {//検索条件が入っていれば
						intIndex.add(i);
						if(isFirst) {
							query.append(" WHERE " + constInts[i]);
							isFirst = false;
						} else {
							if(searchDTO.isAnd()) query.append(" AND " + constInts[i]);
							else query.append(" OR " + constInts[i]);
						}
					}
				}
				ps = c.prepareStatement(query.toString());System.out.println(query.toString());
				int j = 1;
				for(int i : strIndex) {
					if(i == 1) {
						//案件名は1つの検索条件でe.案件名とp.案件名を対象にする
						ps.setString(j, "%" + searchDTO.getStr(i) + "%"); j++;
						ps.setString(j, "%" + searchDTO.getStr(i) + "%"); j++;
					} else {
						ps.setString(j, searchDTO.getStr(i)); j++;
					}
				}
				for(int i : intIndex) {
					ps.setInt(j, searchDTO.getInt(i));System.out.println(j + "," + searchDTO.getInt(i));
					j++;
				}
				rs = ps.executeQuery();
				while(rs.next()) {
					Vector<Object> v2 = new Vector<Object>();
					v2.add(rs.getInt("見積親ID"));
					if(rs.getInt("見積期") != 0 && rs.getInt("見積番号") != 0) {
						v2.add(rs.getInt("見積期") + "-" + rs.getInt("見積番号") + " " + rs.getString("見積枝番"));
					} else {
						v2.add("");
					}
					if(rs.getInt("製作期") != 0 && rs.getInt("製作番号") != 0) {
						v2.add(rs.getInt("製作期") + "-" + rs.getInt("製作番号") + " " + rs.getString("製作枝番"));System.out.println("製作枝番："+rs.getString("製作枝番"));
					} else {
						v2.add("");
					}
					if(rs.getInt("得意先CD") != 0) {
						v2.add(rs.getInt("得意先CD") + "：" + rs.getString("会社名"));
					} else {
						v2.add("");
					}
					v2.add(rs.getString("案件名"));
					v2.add(rs.getInt("種類"));
					v2.add(rs.getDate("依頼年月日"));
					v2.add(rs.getDate("提出年月日"));
					v2.add(rs.getInt("見積金額"));
					v2.add(rs.getString("受注番号"));
					v2.add(rs.getDate("受注年月日"));
					v2.add(rs.getDate("発行年月日"));
					v2.add(rs.getDate("納期"));
					v2.add(rs.getInt("契約金額"));
					v2.add(rs.getInt("納品状況CD"));
					v2.add(rs.getDate("出荷年月日"));
					v2.add(rs.getDate("検収年月日"));

					v.add(v2);
				}

			} catch(SQLException ex) {
				isError = true;
				err.append(className + "テーブル「T_見積_親」の読み出しに失敗しました\n");
				Logging.logStackTrace(ex, lg, className);
			}
		}catch(Exception ex) {
			isError = true;
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * クライアントに送信
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(v);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			lg.error(ex);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}


	public String partialDateStr(String target, String ymd, int begin, int count) {
		switch(begin) {
			case 1 : return "substring(convert(varchar(" + count + "), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
			case 6 : return "substring(convert(varchar(" + (count + 5) + "), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
			default : return "substring(convert(varchar(10), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
		}
	}
}
