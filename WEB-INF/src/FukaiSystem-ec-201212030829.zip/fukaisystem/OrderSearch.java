package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.OrderSearchDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;



public class OrderSearch extends GenericServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "Search\n";

	@Override
	public void service(ServletRequest request, ServletResponse response) {
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean isError = false;
		OrderSearchDTO searchDTO = null;
		StringBuilder err = new StringBuilder();
		List<Integer> strIndex = new ArrayList<Integer>();
		List<Integer> intIndex = new ArrayList<Integer>();

		Vector<Vector<Object>> v = new Vector<Vector<Object>>();

		String[] constStrs = {"�����}��=?", "�����N����=?", "�w��[��=?", "�[�i�N����=?"};
		String[] constInts = {"�d����CD=?", "������=?", "�����ԍ�=?", "�`�[�ԍ�=?"};
		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				isError = true;
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof OrderSearchDTO) {
					searchDTO = (OrderSearchDTO)obj;
				} else {
					isError = true;
					err.append(className + "readObject��ProjectSearchDTO�^�ł͂���܂���\n");
					lg.error(className + "readObject��ProjectSearchDTO�^�ł͂���܂���");
				}
			}
			try {
				StringBuilder query = new StringBuilder(
				 "SELECT ID,������,�����ԍ�,�����}��," +
				 " �`�[�ԍ�,s.�d����CD,�����N����,�w��[��," +
				 " �E�v,�[����w��,��Ж�" +
				 " FROM T_�݌�_�e s" +
				 " LEFT OUTER JOIN (" +
				 "	SELECT �d����CD,��Ж� FROM M_�����@�l" +
				 "	UNION ALL" +
				 "	SELECT �d����CD,��Ж� FROM M_�O���@�l" +
				 " ) c" +
				 " ON s.�d����CD=c.�d����CD");
				boolean isFirst = true;
				//������̌��������́AsearchDTO.getStr(0)
					if(!searchDTO.getStr(0).equals("")) {//���������������Ă����
						isFirst = false;
						strIndex.add(0);
							query.append(" WHERE ");
						query.append(constStrs[0]);
					}
				String y = "", m = "", d = "";
				//�N�����̌��������́AsearchDTO.getStr(1�`9)
				for(int i = 1; i < 9; i++) {
					int reminder = i % 3;
					if(reminder == 1) {
						y = searchDTO.getStr(i);
					} else if(reminder == 2) {
						m = searchDTO.getStr(i);
					} else if(reminder == 0) {
						d = searchDTO.getStr(i);
						if(!(y + m + d).equals("")) {
							boolean eachFlag = false;
							if(isFirst) {
								query.append(" WHERE ");
								isFirst = false;
							} else {
								if(searchDTO.isAnd()) query.append(" AND ");
								else query.append(" OR ");
							}

							if(!y.equals("") && !m.equals("")) {
								if(!d.equals("")) {//�S������
									query.append(partialDateStr(constStrs[(i - 1) / 3 + 1], y + "-" + m + "-" + d, 1, 10));
								} else {//ym�̂�
									query.append(partialDateStr(constStrs[(i - 1) / 3 + 1], y + "-" + m, 1, 7));
								}
							} else if(!m.equals("") && !d.equals("")) {
								query.append(partialDateStr(constStrs[(i - 1) / 3 + 1], m + "-" + d, 6, 5));
							} else {
								if(!y.equals("")) {
									query.append(partialDateStr(constStrs[(i - 1) / 3 + 1], y, 1, 4));
									eachFlag = true;
								}
								if(!m.equals("")) {
									if(eachFlag) {
										if(searchDTO.isAnd()) query.append(" AND ");
										else query.append(" OR ");
									}
									query.append(partialDateStr(constStrs[(i - 1) / 3 + 1], m, 6, 2));
									eachFlag = true;
								}
								if(!d.equals("")) {
									if(eachFlag) {
										if(searchDTO.isAnd()) query.append(" AND ");
										else query.append(" OR ");
									}
									query.append(partialDateStr(constStrs[(i - 1) / 3 + 1], d, 9, 2));
								}
							}
						}
					}
				}
				//���l�̌��������́AsearchDTO.getInt(0�`3)
				for(int i = 0; i < 4; i++) {
					if(searchDTO.getInt(i) != 0) {//���������������Ă����
						intIndex.add(i);
						if(isFirst) {
							query.append(" WHERE " + constInts[i]);
							isFirst = false;
						} else {
							if(searchDTO.isAnd()) query.append(" AND " + constInts[i]);
							else query.append(" OR " + constInts[i]);
						}
					}
				}
				ps = c.prepareStatement(query.toString());System.out.println(query.toString());
				int j = 1;
				for(int i : strIndex) {
					ps.setString(j, searchDTO.getStr(i)); j++;
				}
				for(int i : intIndex) {
					ps.setInt(j, searchDTO.getInt(i));System.out.println(j + "," + searchDTO.getInt(i));
					j++;
				}
				rs = ps.executeQuery();
				while(rs.next()) {
					Vector<Object> v2 = new Vector<Object>();
					v2.add(rs.getInt("ID"));
					if(rs.getInt("������") != 0 && rs.getInt("�����ԍ�") != 0) {
						v2.add(rs.getInt("������") + "-" + rs.getInt("�����ԍ�") + " " + rs.getString("�����}��"));
					} else {
						v2.add("");
					}
					v2.add(rs.getInt("�`�[�ԍ�"));
					if(rs.getInt("�d����CD") != 0) {
						v2.add(rs.getInt("�d����CD") + "�F" + rs.getString("��Ж�"));
					} else {
						v2.add("");
					}
					v2.add(rs.getDate("�����N����"));
					v2.add(rs.getDate("�w��[��"));
					v2.add(rs.getString("�E�v"));
					v2.add(rs.getString("�[����w��"));
					v.add(v2);
				}

			} catch(SQLException ex) {
				isError = true;
				err.append(className + "�e�[�u���uT_����_�e�v�̓ǂݏo���Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}
		}catch(Exception ex) {
			isError = true;
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(v);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			lg.error(ex);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}


	public String partialDateStr(String target, String ymd, int begin, int count) {
		switch(begin) {
			case 1 : return "substring(convert(varchar(" + count + "), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
			case 6 : return "substring(convert(varchar(" + (count + 5) + "), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
			default : return "substring(convert(varchar(10), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
		}
	}
}
