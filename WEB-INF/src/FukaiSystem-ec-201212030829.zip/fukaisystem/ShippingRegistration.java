package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;



import org.apache.log4j.Logger;

import fukaisystem.dto.ShippingDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class ShippingRegistration extends GenericServlet {


	private static final long serialVersionUID = 1L;
    private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "ShippingRegistration\n";

	public void service(ServletRequest request, ServletResponse response) {
System.out.println("!");
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		Statement st = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean isError = false;
		ShippingDTO shippingDTO = null;
		StringBuilder err = new StringBuilder();


		int shippingID = 0;
		int productID = 0;


		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();
			if(obj == null) {
				isError = true;
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof ShippingDTO) {
					shippingDTO = (ShippingDTO)obj;
				} else {
					isError = true;
					err.append(className + "readObject��ShippingDTO�^�ł͂���܂���\n");
					lg.error(className + "readObject��ShippingDTO�^�ł͂���܂���");
				}
			}

			try {
				st = c.createStatement();
				st.executeUpdate("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
				st.executeUpdate("BEGIN TRANSACTION");
			} catch(SQLException ex) {
				System.out.println("00");
				isError = true;
				err.append(className + "�g�����U�N�V�����̊J�n�Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}
			System.out.println("0f0");

			shippingID = shippingDTO.getInt(0);
			productID = shippingDTO.getInt(1);
			if(productID == 0) return;
			System.out.println("0f1");

			if(shippingID == 0) {
				System.out.println("!!0");
				try {
					ps = c.prepareStatement(
					"INSERT INTO T_�o��_�e" +
						" OUTPUT inserted.ID as newId, inserted.�X�V��" +
						" VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
					int i = 1;
					ps.setInt(i, shippingDTO.getInt(2)); i++;//�`�[�ԍ�
					ps.setInt(i, productID); i++;//����eID
					ps.setDate(i, shippingDTO.getDate(0)); i++;//���s�N����
					ps.setDate(i, shippingDTO.getDate(1)); i++;//�o�הN����
					ps.setInt(i, shippingDTO.getInt(3)); i++;//�o�׎�i
					ps.setBoolean(i, shippingDTO.getBool()); i++;//���[FLG
					ps.setTimestamp(i, new Timestamp(new java.util.Date().getTime())); i++;//�X�V��
					ps.setInt(i, 0);//�X�V��CD
					boolean isResultSet = ps.execute();
					int   updateCount = 0;
					while (true) {
					   if (isResultSet) {
					         rs = ps.getResultSet();
					         while (rs.next()) {
					        	shippingID = rs.getInt(1);
					            System.out.println(
					                               "newId: " + rs.getInt(1) +
					                               "�X�V��: " + rs.getTimestamp(2));
					         }
					         rs.close();
					   }
					   else {
					         updateCount = ps.getUpdateCount();
					         if (updateCount == -1) {
					            break;
					         }
					         System.out.println("Update Count: " + updateCount);
					   }
					   isResultSet = ps.getMoreResults();
					}
					System.out.println("!!00");
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "�e�[�u���uT_�o��_�e�v�̍X�V�Ɏ��s���܂���\n");
					Logging.logStackTrace(ex, lg, className);
				}
				System.out.println("0f1");


			} else {
				System.out.println("!!!");
				try {
					ps = c.prepareStatement("UPDATE T_�o��_�e SET �`�[�ԍ�=?, ����eID=?, ���s�N����=?, �o�הN����=?, �o�׎�i=?, ���[FLG=?, �X�V��=?");
					int i = 1;
					ps.setInt(i, shippingDTO.getInt(2)); i++;//�`�[�ԍ�
					ps.setInt(i, productID); i++;//����eID
					ps.setDate(i, shippingDTO.getDate(0)); i++;//���s�N����
					ps.setDate(i, shippingDTO.getDate(1)); i++;//�o�הN����
					ps.setInt(i, shippingDTO.getInt(3)); i++;//�o�׎�i
					ps.setBoolean(i, shippingDTO.getBool()); i++;//���[FLG
					ps.setTimestamp(i, new Timestamp(new java.util.Date().getTime())); i++;//�X�V��
					ps.setInt(i, 0); i++;//�X�V��CD
					ps.executeUpdate();
					ps = c.prepareStatement("DELETE FROM T_�o��_�q WHERE �o�אeID=?");
					ps.setInt(1, shippingID);
					ps.executeUpdate();
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "�o�׃e�[�u���̍폜�Ɏ��s���܂���\n");
					Logging.logStackTrace(ex, lg, className);
				}
			}

			int k = 1;
			try {
				ps = c.prepareStatement(
					"INSERT INTO T_�o��_�q VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
				for(Vector<Object> v : shippingDTO.getVector()) {
					int tag = (Integer)v.get(0);
					if(tag != 0) {
						int i = 1;
						int j = 1;
						ps.setInt(i, k); i++;//ID
						System.out.println(91);
						ps.setInt(i, shippingID); i++;//�o�אeID
						System.out.println(92);
						ps.setInt(i, tag); i++;//�\��CD
						System.out.println(93);
						ps.setString(i, (String)v.get(j)); i++; j++;//�i��
						System.out.println(94);
						ps.setBoolean(i, (Boolean)v.get(j)); i++; j++;//�eFLG
						System.out.println(95);
						ps.setInt(i, (Integer)v.get(j)); i++; j++;//����
						System.out.println(96);
						ps.setInt(i, (Integer)v.get(j)); i++; j++;//���ʒP��CD
						System.out.println(97);
						ps.setString(i, (String)v.get(j));//�L��
						ps.addBatch();
						k++;
					}
				}
				int[] updateCounts = ps.executeBatch();
				lg.info("T_�o��_�q��" + updateCounts.length + "����������܂����B");
			} catch(SQLException ex) {
				isError = true;
				err.append(className + "�e�[�u���uT_�o��_�q�v�̍X�V�Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}
			System.out.println("!!1");

			if(!isError) {
				System.out.println("!!2");
				try {
					st = c.createStatement();
					st.executeUpdate("COMMIT");
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "�R�~�b�g�Ɏ��s���܂���\n");
					Logging.logStackTrace(ex, lg, className);
				}
			}
		}catch(Exception ex) {
			System.out.println("!!3");
			isError = true;lg.debug("error");
			lg.error(ex);
		} finally {
			System.out.println("!!4");
			if(isError) {lg.debug("rollback");
				try{
					st = c.createStatement();
					st.executeUpdate("ROLLBACK");
				} catch(SQLException ex) {
					err.append(className + "���[���o�b�N�Ɏ��s���܂���\n");
					Logging.logStackTrace(ex, lg, className);
				}
			}
		}
		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			System.out.println("!!5");
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			System.out.println("ID:"+ shippingID);
			System.out.println("Err:"+ err.toString());
			out.writeObject(shippingID);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
