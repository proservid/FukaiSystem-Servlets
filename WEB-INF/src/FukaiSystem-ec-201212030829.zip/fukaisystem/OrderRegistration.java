﻿package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.OrderDocumentDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class OrderRegistration extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static final Logger lg = Logger.getLogger("A1");
	private static final String className = "OrderRegistration\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		Statement st = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean isError = false;
		OrderDocumentDTO odd = null;
		String output = "";
		StringBuilder err = new StringBuilder("");
		int orderID = 0;

		try {

			/**
			 * クライアントデータ受け取り
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObjectがnullです\n");
				lg.error(className + "readObjectがnullです");
			} else {
				if(obj instanceof OrderDocumentDTO) {
					odd = (OrderDocumentDTO)obj;
				} else {
					err.append(className + "readObjectがString型ではありません\n");
					lg.error(className + "readObjectがString型ではありません");
				}
			}

			try {
				//コミット後でありさえすればよい。
				//コミット後ということは、子・孫ともども更新されているはずで、問題は生じない
				//親→子→孫（加工→材料）の順が守られている限り、デッドロックは発生しないはず
				st = c.createStatement();
				st.executeUpdate("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
				st.executeUpdate("BEGIN TRANSACTION");
//				st.executeQuery("SELECT COUNT(*) FROM T_在庫_親 WITH(TABLOCKX)");
//				st.executeQuery("SELECT COUNT(*) FROM T_在庫_子 WITH(TABLOCKX)");
			} catch(SQLException ex) {
				isError = true;
				err.append(className + "トランザクションの開始に失敗しました\n");
				Logging.logStackTrace(ex, lg, className);
			}

			orderID = odd.getInt(4);
			if(odd.getInt(1) * odd.getInt(2) == 0) {
				//注文期または注文番号を0に変更したということは、消去せよということ
				if(odd.getInt(3) != 0) {
					try {
						ps = c.prepareStatement("DELETE FROM T_在庫_親 WHERE ID=?");
						ps.setInt(1, odd.getInt(4));
						ps.executeUpdate();
						ps = c.prepareStatement("DELETE FROM T_在庫_子 WHERE ID=?");
						ps.setInt(1, odd.getInt(4));
						ps.executeUpdate();
						orderID = 0;
					} catch(SQLException ex) {
						isError = true;
						err.append(className + "在庫テーブルの削除に失敗しました\n");
						Logging.logStackTrace(ex, lg, className);
					}
				}
			} else {
				if(orderID == 0) {
					try {
						ps = c.prepareStatement(
								"INSERT INTO T_在庫_親" +
								" OUTPUT inserted.ID as newId, inserted.更新日" +
								" VALUES(" +
								" ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," +
								" ?)");
						int i = 1;
						ps.setInt(i, odd.getInt(1)); i++;//注文期
						ps.setInt(i, odd.getInt(2)); i++;//注文番号
						ps.setString(i, odd.getStr(1)); i++;//注文枝番
						ps.setInt(i, odd.getInt(3)); i++;//伝票番号
						ps.setInt(i, odd.getInt(0)); i++;//仕入先CD
						ps.setDate(i, odd.getDate(0)); i++;//注文年月日
						ps.setDate(i, odd.getDate(1)); i++;//指定納期
						ps.setString(i, odd.getStr(2)); i++;//摘要
						ps.setString(i, odd.getStr(3)); i++;//納入先指定
						ps.setTimestamp(i, new Timestamp(new java.util.Date().getTime())); i++;//更新日
						ps.setInt(i, 0);//更新者CD
						boolean isResultSet = ps.execute();
						int   updateCount = 0;
						while (true) {
						   if (isResultSet) {
						         rs = ps.getResultSet();
						         while (rs.next()) {
						        	orderID = rs.getInt(1);
						            System.out.println("newId: " + rs.getInt(1) +
						                               "更新日: " + rs.getTimestamp(2));
						         }
						         rs.close();
						   }
						   else {
						         updateCount = ps.getUpdateCount();
						         if (updateCount == -1) {
						            break;
						         }
						   }
						   isResultSet = ps.getMoreResults();
						}
					} catch(SQLException ex) {
						isError = true;
						err.append(className + "テーブル「T_在庫_親」の更新に失敗しました\n");
						Logging.logStackTrace(ex, lg, className);
					}

				} else {
					try {
						ps = c.prepareStatement("UPDATE T_在庫_親 SET" +
							" 注文期=?, 注文番号=?, 注文枝番=?, 伝票番号=?, 仕入先CD=?, 注文年月日=?, 指定納期=?," +
							" 摘要=?, 納入先指定=?, 更新日=?, 更新者CD=?" +
							" WHERE ID=?");
						int i = 1;
						ps.setInt(i, odd.getInt(1)); i++;//注文期
						ps.setInt(i, odd.getInt(2)); i++;//注文番号
						ps.setString(i, odd.getStr(1)); i++;//注文枝番
						ps.setInt(i, odd.getInt(3)); i++;//伝票番号
						ps.setInt(i, odd.getInt(0)); i++;//仕入先CD
						ps.setDate(i, odd.getDate(0)); i++;//注文年月日
						ps.setDate(i, odd.getDate(1)); i++;//指定納期
						ps.setString(i, odd.getStr(2)); i++;//摘要
						ps.setString(i, odd.getStr(3)); i++;//納入先指定
						ps.setTimestamp(i, new Timestamp(new java.util.Date().getTime())); i++;//更新日
						ps.setInt(i, 0); i++;//更新者CD
						ps.setInt(i, orderID);//ID
						ps.executeUpdate();
						//子孫のデータ更新は、削除→追加にて
						ps = c.prepareStatement("DELETE FROM T_在庫_子 WHERE ID=?");
						//where以降
						i = 1;
						ps.setInt(i, orderID);//ID
						ps.executeUpdate();
					} catch(SQLException ex) {
						isError = true;
						err.append(className + "在庫テーブルの削除に失敗しました\n");
						Logging.logStackTrace(ex, lg, className);
					}
				}

				int k = 1;
				try {
					ps = c.prepareStatement(
						"INSERT INTO T_在庫_子 VALUES(" +
						"?, ?, ?, ?, ?, ?, ?, ?, ?, ?," +
						"?, ?, ?, ?, ?)");
					for(Vector<Object> v : odd.getVector(0)) {
						int i = 1;
						int j = 0;
						ps.setInt(i, k); i++;//ID
						ps.setInt(i, orderID); i++;//親ID
						ps.setInt(i, (v.get(j) == null) ? 0 : (Integer)v.get(j)); i++; j++;//大分類CD
						ps.setInt(i, (v.get(j) == null) ? 0 : (Integer)v.get(j)); i++; j++;//中分類CD
						ps.setInt(i, (v.get(j) == null) ? 0 : (Integer)v.get(j)); i++; j++;//小分類CD
						ps.setString(i, (String)v.get(j)); i++; j++;//名称
						ps.setBoolean(i, (Boolean)v.get(j)); i++; j++;//各FLG
						ps.setInt(i, (Integer)v.get(j)); i++; j++;//数量
						ps.setInt(i, (Integer)v.get(j)); i++; j++;//数量単位CD
						ps.setInt(i, ((Float)v.get(j)).intValue()); i++; j++;//重量長さ（単位を要検討のこと）
						ps.setInt(i, (Integer)v.get(j)); i++; j++;//単価
						ps.setInt(i, (Integer)v.get(j)); i++; j++;//金額
						ps.setString(i, (String)v.get(j)); i++;//備考
						ps.setDate(i, null); i++;//入庫年月日
						ps.setDate(i, null);//出庫年月日
						ps.addBatch();
						k++;
					}
					int[] updateCounts = ps.executeBatch();
					lg.info("T_在庫_子は" + updateCounts.length + "件処理されました。");
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "テーブル「T_在庫_子」の更新に失敗しました\n");
					Logging.logStackTrace(ex, lg, className);
				}
			}

			if(!isError) {
				try {
					st = c.createStatement();
					st.executeUpdate("COMMIT");
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "コミットに失敗しました\n");
					Logging.logStackTrace(ex, lg, className);
				}
			}
		} catch(Exception ex) {
			isError = true;lg.debug("error");
			lg.error(ex);
		} finally {
			if(isError) {lg.debug("rollback");
				try{
					st = c.createStatement();
					st.executeUpdate("ROLLBACK");
				} catch(SQLException ex) {
					err.append(className + "ロールバックに失敗しました\n");
					Logging.logStackTrace(ex, lg, className);
				}
			}
		}

		/**
		 * クライアントに送信
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(orderID);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}
}
