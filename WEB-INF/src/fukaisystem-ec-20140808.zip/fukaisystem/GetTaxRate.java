package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class GetTaxRate extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetTaxRate\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String input = "";
		String output = "";
		StringBuilder err = new StringBuilder("");

		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof String) {
					input = (String)obj;
				} else {
					err.append(className + "readObject��String�^�ł͂���܂���\n");
					lg.error(className + "readObject��String�^�ł͂���܂���");
				}
			}

			try {
				ps = c.prepareStatement("SELECT �ŗ� FROM M_����� t WHERE �K�p�J�n��<=? AND NOT EXISTS" +
						" (SELECT 1 FROM M_����� t2 WHERE t.�K�p�J�n��<t2.�K�p�J�n�� AND �K�p�J�n��<=?)");
				ps.setString(1, input);
				ps.setString(2, input);
				rs = ps.executeQuery();
				while(rs.next()) {
					output = rs.getString("�ŗ�");
				}
			} catch(SQLException ex) {
				err.append("�e�[�u���uT_�e�[�u�����v�̓Ǎ��Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}

		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(output);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}
}
