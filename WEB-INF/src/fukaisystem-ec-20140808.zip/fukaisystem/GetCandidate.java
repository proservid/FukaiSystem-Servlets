package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.CandidateInputDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class GetCandidate extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetCandidate\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String input = "";
		StringBuilder err = new StringBuilder("");
		String key = "";
		boolean isValidOnly = false;

		Vector<Vector<String>> candidate = new Vector<Vector<String>>();
		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof CandidateInputDTO) {
					CandidateInputDTO ciDTO = (CandidateInputDTO)obj;
					input = ciDTO.getInput();
					key = ciDTO.isSupplier() ? "�d����CD" : "���Ӑ�CD" ;
					isValidOnly = ciDTO.isValidOnly();
				} else if(obj instanceof String) {
					input = (String)obj;
					key = "CD";
				} else {
					err.append(className + "readObject��String�^�ł͂���܂���\n");
					lg.error(className + "readObject��String�^�ł͂���܂���");
				}
			}

			try {
				StringBuilder sql = new StringBuilder("SELECT CD, " + key + "," +
						"CASE" +
						" WHEN ���CD = 1 THEN '��'+��Ж� + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
						" WHEN ���CD = 2 THEN ��Ж�+'��' + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
						" WHEN ���CD = 3 THEN '��'+��Ж� + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
						" WHEN ���CD = 4 THEN ��Ж�+'��' + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
						" ELSE ��Ж� + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
						" END AS �Ж�" +
						" FROM M_�@�l" +
						" WHERE " + key + " IS NOT NULL AND (��Ж� LIKE ? OR �x�X�� LIKE ? OR �J�C�V�����C LIKE ? OR �V�e�����C LIKE ? OR �A���t�@�x�b�g LIKE ? OR �d����CD LIKE ? OR ���Ӑ�CD LIKE ?)");
				if(isValidOnly) {
					sql.append(" AND �L��FLG='true'");
				}
				sql.append(" ORDER BY " + key);
				ps = c.prepareStatement(sql.toString());
				int i = 1;
				ps.setString(i++, "%" + input + "%");
				ps.setString(i++, "%" + input + "%");
				ps.setString(i++, "%" + input + "%");
				ps.setString(i++, "%" + input + "%");
				ps.setString(i++, "%" + input + "%");
				ps.setString(i++, input + "%");
				ps.setString(i++, input + "%");
				rs = ps.executeQuery();
				while(rs.next()) {
					Vector<String> v = new Vector<String>();
					v.add(rs.getString("CD"));
					v.add(rs.getString(key));
					v.add(rs.getString("�Ж�"));
					candidate.add(v);
				}
			} catch(SQLException ex) {
				err.append(ex.getMessage());
				err.append("ErrorCode�F"+ex.getErrorCode());
				err.append("SQLState�F"+ex.getSQLState());
				err.append("�e�[�u���uT_�e�[�u�����v�̓Ǎ��Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
				ex.printStackTrace();
			}

		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
			ex.printStackTrace();
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(candidate);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
			ex.printStackTrace();
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}
}
