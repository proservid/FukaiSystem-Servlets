package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.ChartDTO;
import fukaisystem.dto.ProductNumber;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;

public class SetCombo extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
    private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "SetCombo\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuilder err = new StringBuilder();

		int code = 0;
		String name = "";
		String display = "";

		Map<Integer, String> contacts = new LinkedHashMap<Integer, String>();
		Map<Integer, String> models = new LinkedHashMap<Integer, String>();
		Map<Integer, ProductNumber> numbers = new HashMap<Integer, ProductNumber>();

		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof Integer) {
					code = (Integer)obj;
				} else {
					err.append(className + "readObject��String�^�ł͂���܂���\n");
					lg.error(className + "readObject��String�^�ł͂���܂���");
				}
			}

			try {
				ps = c.prepareStatement("SELECT" +
					" CASE" +
					" WHEN ���CD = 1 THEN '��'+��Ж� + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
					" WHEN ���CD = 2 THEN ��Ж�+'��' + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
					" WHEN ���CD = 3 THEN '��'+��Ж� + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
					" WHEN ���CD = 4 THEN ��Ж�+'��' + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
					" ELSE ��Ж� END," +
					" �\����" +
					" FROM  M_�@�l c" +
					" WHERE ���Ӑ�CD=?");
				ps.setInt(1, code);
				rs = ps.executeQuery();
				if(rs.next()) {
					name = rs.getString(1);
					display = rs.getString(2);
				}
				ps = c.prepareStatement("SELECT �@�B�ԍ�,�Č���,�����,����ԍ�,����}�� FROM T_����_�e" +
						" WHERE ���Ӑ�CD=? AND �@�B�ԍ�>0 ORDER BY �����,����ԍ�");
				ps.setInt(1, code);
				rs = ps.executeQuery();
				while(rs.next()) {
					models.put(rs.getInt("�@�B�ԍ�"), rs.getString("�Č���"));
					numbers.put(rs.getInt("�@�B�ԍ�"), new ProductNumber(rs.getInt("�����"),rs.getInt("����ԍ�"),rs.getString("����}��")));
				}

				ps = c.prepareStatement("SELECT p.CD, CASE WHEN �� IS NULL THEN �� ELSE ��+' '+�� END AS ���� FROM M_�l p" +
						 " LEFT OUTER JOIN M_�@�l c" +
						 " ON p.�@�lCD=c.CD" +
						" WHERE ���Ӑ�CD=? ORDER BY p.CD");
				ps.setInt(1, code);
				rs = ps.executeQuery();
				while(rs.next()) {
					contacts.put(rs.getInt("CD"), rs.getString("����"));
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
				Logging.logStackTrace(ex, lg, className);
			}


			/**
			 * �N���C�A���g�ɑ��M
			 */

			ChartDTO cd = new ChartDTO(name, display, contacts, models, numbers);
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(cd);
			out.writeUTF("acitve:"+dbc.getNumActive()+" idle:"+dbc.getNumIdle());
			out.flush();
			out.close();

		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
