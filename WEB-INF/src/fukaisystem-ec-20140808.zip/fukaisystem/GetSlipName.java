	package fukaisystem;

	import java.io.ObjectInputStream;
	import java.io.ObjectOutputStream;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
import java.util.Vector;

	import javax.servlet.GenericServlet;
	import javax.servlet.ServletRequest;
	import javax.servlet.ServletResponse;

	import org.apache.log4j.Logger;

import fukaisystem.dto.SlipSelectDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


	public class GetSlipName extends GenericServlet {

		/**
		 *
		 */
		private static final long serialVersionUID = 1L;
	    private static final Logger lg = Logger.getLogger("A1");
		private static final String className = "GetSlipName\n";

		public void service(ServletRequest request, ServletResponse response) {

			DBConnection dbc = new DBConnection();
			Connection c = dbc.getConnection();
			PreparedStatement ps = null;
			ResultSet rs = null;
			String input = "";
			Object output = "";
			Vector<String> candidate = new Vector<String>();
			Vector<Vector<String>> tableData = new Vector<Vector<String>>();
			StringBuilder err = new StringBuilder("");

			try {

				/**
				 * �N���C�A���g�f�[�^�󂯎��
				 */
				ObjectInputStream in = new ObjectInputStream(request.getInputStream());
				Object obj = in.readObject();
				in.close();

				if(obj == null) {
					err.append(className + "readObject��null�ł�\n");
					lg.error(className + "readObject��null�ł�");
				} else {
					if(obj instanceof String) {
						input = (String)obj;
					} else {
						err.append(className + "readObject��String�^�ł͂���܂���\n");
						lg.error(className + "readObject��String�^�ł͂���܂���");
					}
				}

				if(input.equals("")) {
					candidate.add("");//�܂��A��f�[�^��ǉ�
					//�o�^����Ă���쐬�f�[�^���擾
					try {
						ps = c.prepareStatement("SELECT ���[�� FROM T_���[ ORDER BY ���[��");
						rs = ps.executeQuery();
						while(rs.next()) {
							candidate.add(rs.getString("���[��"));
						}
					} catch(SQLException ex) {
						err.append(className + "�e�[�u���uT_���[�v�̓Ǎ��Ɏ��s���܂���\n");
						Logging.logStackTrace(ex, lg, className);
					}
					//
					try {
						ps = c.prepareStatement("SELECT ���[��,���^�� FROM T_���[�I��");
						rs = ps.executeQuery();
						while(rs.next()) {
							Vector<String> v = new Vector<String>();
							v.add(rs.getString("���[��"));
							v.add(rs.getString("���^��"));
							tableData.add(v);
						}
						output = tableData;
					} catch(SQLException ex) {
						err.append(className + "�e�[�u���uT_���[�I���v�̓Ǎ��Ɏ��s���܂���\n");
						Logging.logStackTrace(ex, lg, className);
					}
					output = new SlipSelectDTO(candidate, tableData);
				} else {
					try {
						ps = c.prepareStatement("SELECT ���^�� FROM T_���[�I�� WHERE ���[��=?");
						ps.setString(1, input);
						rs = ps.executeQuery();
						while(rs.next()) {
							output = rs.getString("���^��");
						}
					} catch(SQLException ex) {
						err.append(className + "�e�[�u���uT_���[�I���v�̓Ǎ��Ɏ��s���܂���\n");
						Logging.logStackTrace(ex, lg, className);
					}
				}

			} catch(Exception ex) {
				Logging.logStackTrace(ex, lg, className);
			}

			/**
			 * �N���C�A���g�ɑ��M
			 */
			try {
				response.setContentType("application/octet-stream");
				ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
				out.writeObject(output);
				out.writeUTF(err.toString());
				out.flush();
				out.close();
			}catch(Exception ex) {
				Logging.logStackTrace(ex, lg, className);
			} finally {
				try {
					if(c != null && !c.isClosed()) c.close();
				} catch(SQLException ex) {
					Logging.logStackTrace(ex, lg, className);
				}
	// The following processes requires JDBC4.0.
				try {
					if(ps != null && !ps.isClosed()) {
						ps.close();
						lg.debug(className + "ps is closed by jdbc4.0");
					}
				} catch(SQLException ex) {
					Logging.logStackTrace(ex, lg, className);
				}
				try {
					if(rs != null && !rs.isClosed()) {
						rs.close();
						lg.debug(className + "rs is closed by jdbc4.0");
					}
				} catch(SQLException ex) {
					Logging.logStackTrace(ex, lg, className);
				}
			}
		}

	}
