package fukaisystem.input;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.InitialInputDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;

public class InitInputSystem extends GenericServlet {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
   private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "InitInputSystem\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;

		TreeMap<String, String> dept = new TreeMap<String, String>();
		Map<String, String> process = new LinkedHashMap<String, String>();
		Map<List<String>, Map<String, String>> name = new LinkedHashMap<List<String>, Map<String, String>>();
		int period = 0;

		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			in.close();

			try {
				ps = c.prepareStatement("SELECT RIGHT('00' + CONVERT(varchar, CD), 2) AS ����CD,������ FROM M_����");
				rs = ps.executeQuery();
				while(rs.next()) {
					dept.put(rs.getString("����CD"), rs.getString("������"));
				}

				ps = c.prepareStatement("" +
					"SELECT CASE WHEN ��������CD IN(1,2,3) THEN RIGHT('00' + CONVERT(varchar, CD), 2) ELSE CONVERT(varchar, CD) END AS �lCD,��+' '+�� AS ����,RIGHT('00' + CONVERT(varchar, ��������CD), 2) AS ����CD" +
					" FROM M_�l�� WHERE �ݐ�FLG='true' ORDER BY �\��CD");
				rs = ps.executeQuery();
				while(rs.next()) {
					List<String> subKey = new ArrayList<String>();
					subKey.add(rs.getString("����CD"));
					if(!name.containsKey(subKey)) {
						name.put(subKey, new LinkedHashMap<String, String>());
					}
					name.get(subKey).put(rs.getString("�lCD"), rs.getString("����"));
				}

				ps = c.prepareStatement("SELECT RIGHT('00' + CONVERT(varchar, CD), 2) AS ������CD,�����ޖ� FROM M_���H_�q WHERE �g�pFLG='true' AND CD<100 ORDER BY �啪��CD,������CD");
				rs = ps.executeQuery();
				while(rs.next()) {
					process.put(rs.getString("������CD"), rs.getString("�����ޖ�"));
				}

				ps = c.prepareStatement("SELECT MAX(��) AS ���� FROM M_�� WHERE �� < ?");
				ps.setDate(1, new java.sql.Date(new java.util.Date().getTime()));
				rs = ps.executeQuery();
				if(rs.next()) {
					period = rs.getInt("����");
				}


			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}


			/**
			 * �N���C�A���g�ɑ��M
			 */

			InitialInputDTO iid = new InitialInputDTO(dept, name, process, period);

			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(iid);
			out.writeUTF("acitve:"+dbc.getNumActive()+" idle:"+dbc.getNumIdle());
			out.flush();
			out.close();

		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
//The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
