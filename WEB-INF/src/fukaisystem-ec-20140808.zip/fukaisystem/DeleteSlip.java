package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;

public class DeleteSlip extends GenericServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "DeleteSlip\n";

	@Override
	public void service(ServletRequest request, ServletResponse response) {
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuilder err = new StringBuilder();

		String query1 = "", query2 = "";
		int type = 0, id = 0;


		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				id = 0;
			} else {
				if(obj instanceof Integer[]) {
					Integer[] param = (Integer[])obj;
					type = param[0];
					id = param[1];
					switch(type) {
						case 1 :
							query1 ="DELETE FROM T_����_�e WHERE ���ϐeID=?";
							query2 ="DELETE FROM T_����_�q WHERE ���ϐeID=?";
							break;
						case 2 :
							query1 ="DELETE FROM T_����_�e WHERE ����eID=?";
							query2 ="DELETE FROM T_����_�q WHERE ����eID=?";
							break;
						case 3 :
							query1 ="DELETE FROM T_�݌�_�e WHERE �݌ɐeID=?";
							query2 ="DELETE FROM T_�݌�_�q WHERE �݌ɐeID=?";
							break;
						case 4 :
							query1 ="DELETE FROM T_����_�e WHERE ����eID=?";
							query2 ="DELETE FROM T_����_�q WHERE ����eID=?";
							break;
						case 5 :
							query1 ="DELETE FROM T_�o��_�e WHERE �o�ɐeID=?";
							query2 ="DELETE FROM T_�o��_�q WHERE �o�ɐeID=?";
							break;
					}
				} else {
					err.append(className + "readObject��Integer�^�ł͂���܂���\n");
					lg.error(className + "readObject��Integer�^�ł͂���܂���");
				}
			}
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		if(type > 0) {
			try {
				ps = c.prepareStatement(query1);
				ps.setInt(1, id);
				ps.executeUpdate();

				//����
				ps = c.prepareStatement(query2);
				ps.setInt(1, id);
				ps.executeUpdate();
System.out.println(query1);
System.out.println(query2);
System.out.println(id);

			}catch(SQLException ex) {
				err.append(ex.toString());
				Logging.logStackTrace(ex, lg, className);
			}
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(null);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
