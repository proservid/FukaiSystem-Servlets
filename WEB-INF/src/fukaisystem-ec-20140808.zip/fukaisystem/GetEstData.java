package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.HistoryDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;



public class GetEstData extends GenericServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetEstData\n";

	@SuppressWarnings("unchecked")
	@Override
	public void service(ServletRequest request, ServletResponse response) {
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuilder err = new StringBuilder();
		List<String> nums = null;
		Vector<Vector<Object>> v = new Vector<Vector<Object>>();

		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof List<?>) {
					nums = (List<String>)obj;
				} else {
					err.append(className + "readObject��ProjectSearchDTO�^�ł͂���܂���\n");
					lg.error(className + "readObject��ProjectSearchDTO�^�ł͂���܂���");
				}
			}
			try {
				StringBuilder query = new StringBuilder(
				 "select * from T_����_�q where ���ϐeID IN (select ���ϐeID from (" +
				 "select ���ϐeID,convert(varchar,���ϊ�)+'-'+right('000' + convert(varchar, ���ϔԍ�), 3)+���ώ}�� as ���ϔ� from T_����_�e) a" +
				 " where ");
				boolean isFirst = true;
				for(String s : nums) {
					if(isFirst) {
						query.append("���ϔ� like '" + s + "'");
						isFirst = false;
					} else {
						query.append(" OR ���ϔ� like '" + s + "'");
					}
				}
				query.append(") order by ���ϐeID,ID");
				ps = c.prepareStatement(query.toString());
				System.out.println(query.toString());
				rs = ps.executeQuery();
				while(rs.next()) {
					Vector<Object> line = new Vector<Object>();
					line.add(rs.getInt("ID"));
					line.add(rs.getInt("�\��CD"));
					line.add(rs.getString("����"));
					line.add(rs.getBoolean("�eFLG"));
					line.add(rs.getInt("����"));
					line.add(rs.getInt("���ʒP��CD"));
					line.add(rs.getInt("�P��"));
					line.add(rs.getInt("�񎦊z"));
					line.add(rs.getString("�}��"));
					line.add(rs.getString("���l"));
					v.add(line);
				}

			} catch(SQLException ex) {
				err.append(className + "�e�[�u���uT_�݌�_�e�v�̓ǂݏo���Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(v);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			lg.error(ex);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}


	public String partialDateStr(String target, String ymd, int begin, int count) {
		switch(begin) {
			case 1 : return "substring(convert(varchar(" + count + "), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
			case 6 : return "substring(convert(varchar(" + (count + 5) + "), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
			default : return "substring(convert(varchar(10), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
		}
	}
}
