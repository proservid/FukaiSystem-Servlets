package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;

public class SetLabel extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
    private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "SetLabel\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuilder err = new StringBuilder();

		int code = 0;
		String name = "";

		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();
			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof Integer) {
					code = (Integer)obj;
				} else {
					err.append(className + "readObject��String�^�ł͂���܂���\n");
					lg.error(className + "readObject��String�^�ł͂���܂���");
				}
			}

			try {
				ps = c.prepareStatement("SELECT" +
					" CASE" +
					" WHEN ���CD = 1 THEN '��'+��Ж� + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
					" WHEN ���CD = 2 THEN ��Ж�+'��' + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
					" WHEN ���CD = 3 THEN '��'+��Ж� + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
					" WHEN ���CD = 4 THEN ��Ж�+'��' + CASE WHEN �x�X�� IS NULL THEN '' ELSE ' ' + �x�X�� END" +
					" ELSE ��Ж� END" +
					" FROM M_�@�l c" +
					" WHERE �d����CD=?");
				ps.setInt(1, code);
				rs = ps.executeQuery();
				if(rs.next()) {
					name = rs.getString(1);
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}


			/**
			 * �N���C�A���g�ɑ��M
			 */

			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(name);
			out.writeUTF("acitve:"+dbc.getNumActive()+" idle:"+dbc.getNumIdle());
			out.flush();
			out.close();

		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
