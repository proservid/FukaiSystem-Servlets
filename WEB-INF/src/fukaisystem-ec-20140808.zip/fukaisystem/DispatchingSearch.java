package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.DispatchingDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;



public class DispatchingSearch extends GenericServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "DispatchingSearch\n";

	@Override
	public void service(ServletRequest request, ServletResponse response) {
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		DispatchingDTO dispatchingDTO = null;
		StringBuilder err = new StringBuilder();
		List<Integer> strIndex = new ArrayList<Integer>();
		List<Integer> intIndex = new ArrayList<Integer>();

		Vector<Vector<Object>> v = new Vector<Vector<Object>>();

		String[] constStrs = {
			"����}�� like ?",
			"SUBSTRING(CONVERT(VARCHAR, �o�ɔN����),1,4) like ?", "SUBSTRING(CONVERT(VARCHAR, �o�ɔN����),6,2) like ?", "SUBSTRING(CONVERT(VARCHAR, �o�ɔN����),9,2) like ?",
			"�p�r like ?", "�E�v like ?"};
		String[] constInts = {"�����=?", "����ԍ�=?", "�啪��CD=?", "������CD=?", "������CD=?"};
		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof DispatchingDTO) {
					dispatchingDTO = (DispatchingDTO)obj;
				} else {
					err.append(className + "readObject��ProjectSearchDTO�^�ł͂���܂���\n");
					lg.error(className + "readObject��ProjectSearchDTO�^�ł͂���܂���");
				}
			}
			try {
				StringBuilder query = new StringBuilder(
				 "SELECT * FROM (SELECT p.�o�ɐeID,�����,����ԍ�,����}��,�o�ɔN����,�p�r,�E�v" +
				 " FROM T_�o��_�e p" +
				 " LEFT OUTER JOIN T_�o��_�q c" +
				 " ON p.�o�ɐeID=c.�o�ɐeID");
				boolean isFirst = true;
				for(int i = 0; i < 6; i++) {
					if(!dispatchingDTO.getStr(i).equals("")) {//���������������Ă����
						strIndex.add(i);
						if(isFirst) {
							query.append(" WHERE ");
							isFirst = false;
						} else {
							if(dispatchingDTO.isAnd()) query.append(" AND ");
							else query.append(" OR ");
						}
						query.append(constStrs[i]);
					}
				}

				//���l�̌��������́AsearchDTO.getInt(0�`4)
				for(int i = 0; i < 5; i++) {
					if(dispatchingDTO.getInt(i) != 0) {//���������������Ă����
						intIndex.add(i);
						if(isFirst) {
							query.append(" WHERE " + constInts[i]);
							isFirst = false;
						} else {
							if(dispatchingDTO.isAnd()) query.append(" AND " + constInts[i]);
							else query.append(" OR " + constInts[i]);
						}
					}
				}
				query.append(") a GROUP BY �o�ɐeID,�����,����ԍ�,����}��,�o�ɔN����,�p�r,�E�v");
				ps = c.prepareStatement(query.toString());
				System.out.println(query.toString());
				int j = 1;
				for(int i : strIndex) {
					ps.setString(j, dispatchingDTO.getStr(i)); j++;
				}
				for(int i : intIndex) {
					ps.setInt(j, dispatchingDTO.getInt(i)); j++;
				}
				rs = ps.executeQuery();
				while(rs.next()) {
					Vector<Object> v2 = new Vector<Object>();
					v2.add(rs.getInt("�o�ɐeID"));
					if(rs.getInt("�����") != 0 && rs.getInt("����ԍ�") != 0) {
						v2.add(rs.getInt("�����") + "-" + rs.getInt("����ԍ�") + " " + rs.getString("����}��"));
					} else {
						v2.add("");
					}
					v2.add(rs.getDate("�o�ɔN����"));
					v2.add(rs.getString("�p�r"));
					v2.add(rs.getString("�E�v"));
					v.add(v2);
				}

			} catch(SQLException ex) {
				err.append(className + "�e�[�u���uT_����_�e�v�̓ǂݏo���Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(v);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			lg.error(ex);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}


	public String partialDateStr(String target, String ymd, int begin, int count) {
		switch(begin) {
			case 1 : return "substring(convert(varchar(" + count + "), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
			case 6 : return "substring(convert(varchar(" + (count + 5) + "), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
			default : return "substring(convert(varchar(10), " + target + ", 120), " + begin + ", " + count + ")='" + ymd + "'";
		}
	}
}
