package fukaisystem.address;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;



import org.apache.log4j.Logger;

import fukaisystem.dto.CorpDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class CorpRegistration extends GenericServlet {


	private static final long serialVersionUID = 1L;
    private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "CorpRegistration\n";

	public void service(ServletRequest request, ServletResponse response) {
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean isError = false;
		CorpDTO corpDTO = null;
		StringBuilder err = new StringBuilder();
		String idStr = "";
		boolean isDel = false;
		String cd = "0";


		try {
			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();
			if(obj == null) {
				isError = true;
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof CorpDTO) {
					corpDTO = (CorpDTO)obj;
				} else if(obj instanceof String) {
					idStr = (String)obj;
					isDel = true;
				} else {
					isError = true;
					err.append(className + "readObject��DispatchDTO�^�ł͂���܂���\n");
					lg.error(className + "readObject��DispatchDTO�^�ł͂���܂���");
				}
			}

			if(isDel) {
				try {
					ps = c.prepareStatement(
							"DELETE FROM M_�@�l WHERE CD=?");
					ps.setString(1, idStr);
					ps.executeUpdate();
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "�e�[�u���̍폜�Ɏ��s���܂���\n");
					Logging.logStackTrace(ex, lg, className);
				}
			} else {
				cd = corpDTO.getStr(22);
				try {
					if(cd.equals("0") || cd == null) {//�V�K�ǉ�
						ps = c.prepareStatement("INSERT INTO M_�@�l" +
							" (�d����CD, ���Ӑ�CD, ���CD, ��Ж�, �J�C�V�����C," +
							" �x�X��, �V�e�����C, �\����, �A���t�@�x�b�g, alpha_2, �X�֔ԍ�, �X�֎}��," +//7
							" ���擙, �Ԓn, ������, TEL1, TEL2, TEL3, FAX1, FAX2, FAX3," +//9
							" ���[��, URL, ���l, �L��FLG, ����FLG, �N���CD)" +
							" OUTPUT inserted.CD as newId" +
							" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
						int i = 1;
						ps.setInt(i++, corpDTO.getInt(0));
						ps.setInt(i++, corpDTO.getInt(1));
						ps.setInt(i++, corpDTO.getInt(2));
						ps.setString(i++, corpDTO.getStr(0));
						ps.setString(i++, corpDTO.getStr(1));
						ps.setString(i++, corpDTO.getStr(2));
						ps.setString(i++, corpDTO.getStr(3));
						ps.setString(i++, corpDTO.getStr(4));
						ps.setString(i++, corpDTO.getStr(23));
						ps.setString(i++, corpDTO.getStr(5));
						ps.setString(i++, corpDTO.getStr(6));
						ps.setString(i++, corpDTO.getStr(7));
						ps.setString(i++, corpDTO.getStr(10));
						ps.setString(i++, corpDTO.getStr(11));
						ps.setString(i++, corpDTO.getStr(12));
						ps.setString(i++, corpDTO.getStr(13));
						ps.setString(i++, corpDTO.getStr(14));
						ps.setString(i++, corpDTO.getStr(15));
						ps.setString(i++, corpDTO.getStr(16));
						ps.setString(i++, corpDTO.getStr(17));
						ps.setString(i++, corpDTO.getStr(18));
						ps.setString(i++, corpDTO.getStr(19));
						ps.setString(i++, corpDTO.getStr(20));
						ps.setString(i++, corpDTO.getStr(21));
						ps.setBoolean(i++, corpDTO.getBool(0));
						ps.setBoolean(i++, corpDTO.getBool(1));
						//ps.setString(i, corpDTO.getStr(22));
						ps.setInt(i, corpDTO.getInt(3));
						boolean isResultSet = ps.execute();
						int   updateCount = 0;
						while (true) {
						   if (isResultSet) {
						         rs = ps.getResultSet();
						         while (rs.next()) {
						        	cd = rs.getString(1);
						            System.out.println("newId: " + rs.getInt(1));
						         }
						         rs.close();
						   }
						   else {
						         updateCount = ps.getUpdateCount();
						         if (updateCount == -1) {
						            break;
						         }
						   }
						   isResultSet = ps.getMoreResults();
						}
					} else {//�X�V
						ps = c.prepareStatement("UPDATE M_�@�l SET" +
							" �d����CD=?, ���Ӑ�CD=?, ���CD=?, ��Ж�=?, �J�C�V�����C=?," +
							" �x�X��=?, �V�e�����C=?, �\����=?, �A���t�@�x�b�g=?, alpha_2=?, �X�֔ԍ�=?, �X�֎}��=?," +//7
							" ���擙=?, �Ԓn=?, ������=?, TEL1=?, TEL2=?, TEL3=?, FAX1=?, FAX2=?, FAX3=?," +//9
							" ���[��=?, URL=?, ���l=?, �L��FLG=?, ����FLG=?, �N���CD=?" +//6
							" WHERE CD=?");
						int i = 1;
						ps.setInt(i++, corpDTO.getInt(0));
						ps.setInt(i++, corpDTO.getInt(1));
						ps.setInt(i++, corpDTO.getInt(2));
						ps.setString(i++, corpDTO.getStr(0));
						ps.setString(i++, corpDTO.getStr(1));
						ps.setString(i++, corpDTO.getStr(2));
						ps.setString(i++, corpDTO.getStr(3));
						ps.setString(i++, corpDTO.getStr(4));
						ps.setString(i++, corpDTO.getStr(23));
						ps.setString(i++, corpDTO.getStr(5));
						ps.setString(i++, corpDTO.getStr(6));
						ps.setString(i++, corpDTO.getStr(7));
						ps.setString(i++, corpDTO.getStr(10));
						ps.setString(i++, corpDTO.getStr(11));
						ps.setString(i++, corpDTO.getStr(12));
						ps.setString(i++, corpDTO.getStr(13));
						ps.setString(i++, corpDTO.getStr(14));
						ps.setString(i++, corpDTO.getStr(15));
						ps.setString(i++, corpDTO.getStr(16));
						ps.setString(i++, corpDTO.getStr(17));
						ps.setString(i++, corpDTO.getStr(18));
						ps.setString(i++, corpDTO.getStr(19));
						ps.setString(i++, corpDTO.getStr(20));
						ps.setString(i++, corpDTO.getStr(21));
						ps.setBoolean(i++, corpDTO.getBool(0));
						ps.setBoolean(i++, corpDTO.getBool(1));
						System.out.println(corpDTO.getInt(3));
						ps.setInt(i++, corpDTO.getInt(3));
						ps.setString(i, corpDTO.getStr(22));
						ps.executeUpdate();
					}
				} catch(SQLException ex) {
					isError = true;
					Logging.logStackTrace(ex, lg, className);
					ex.printStackTrace();
				}
			}

		} catch(Exception ex) {
			ex.printStackTrace();
			isError = true;lg.debug("error");
			lg.error(ex);
		}
		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(cd);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		} catch(Exception ex) {
			ex.printStackTrace();
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
