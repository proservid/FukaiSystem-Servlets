package fukaisystem.address;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.CorpDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class GetCountry extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetCountry\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String input = "";
		List<String> output = new ArrayList<String>();
		StringBuilder err = new StringBuilder("");

		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof String) {
					input = (String)obj;
				} else {
					err.append(className + "readObject��String�^�ł͂���܂���\n");
					lg.error(className + "readObject��String�^�ł͂���܂���");
				}
			}
System.out.println(input);
			try {
				ps = c.prepareStatement(
					"select ccTLD,���ۓd�b���ԍ�,����,�p�ꖼ," +
					"case when �X�֔ԍ� is null then '#' else �X�֔ԍ� end as �X�֔ԍ�" +
					" from M_�� where alpha_2=?");
				ps.setString(1, input);
				rs = ps.executeQuery();
				if(rs.next()) {
					output.add(rs.getString("ccTLD"));
					output.add(rs.getString("���ۓd�b���ԍ�"));
					output.add(rs.getString("����"));
					output.add(rs.getString("�p�ꖼ"));
					output.add(rs.getString("�X�֔ԍ�"));
				}
			} catch(SQLException ex) {
				err.append("�e�[�u���uT_�e�[�u�����v�̓Ǎ��Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}

		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(output);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}
}
