package fukaisystem.address;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.CandidateInputDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class GetIndCandidate extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetCandidate\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String input = "";
		StringBuilder err = new StringBuilder("");
		boolean isValidOnly = false;

		Vector<Vector<String>> candidate = new Vector<Vector<String>>();
		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof CandidateInputDTO) {
					CandidateInputDTO ciDTO = (CandidateInputDTO)obj;
					input = ciDTO.getInput();
					isValidOnly = ciDTO.isValidOnly();
				} else {
					err.append(className + "readObject��String�^�ł͂���܂���\n");
					lg.error(className + "readObject��String�^�ł͂���܂���");
				}
			}

			try {
				StringBuilder sql = new StringBuilder("SELECT i.CD, ����, '(' + ��Ж� + ')' AS ��Ж�" +
						" FROM M_�l i" +
						" LEFT OUTER JOIN M_�@�l c ON i.�@�lCD=c.CD" +
						" WHERE i.CD IS NOT NULL AND (���� LIKE ? OR �V���C LIKE ?)");
				if(isValidOnly) {
					sql.append(" AND i.�L��FLG='true'");
				}
				sql.append(" ORDER BY i.CD");
				ps = c.prepareStatement(sql.toString());
				int i = 1;
				ps.setString(i++, "%" + input + "%");
				ps.setString(i++, "%" + input + "%");
				rs = ps.executeQuery();
				while(rs.next()) {
					Vector<String> v = new Vector<String>();
					v.add(rs.getString("CD"));
					v.add(rs.getString("����") + " " + rs.getString("��Ж�"));
					candidate.add(v);
				}
			} catch(SQLException ex) {
				err.append(ex.getMessage());
				err.append("ErrorCode�F"+ex.getErrorCode());
				err.append("SQLState�F"+ex.getSQLState());
				err.append("�e�[�u���uT_�e�[�u�����v�̓Ǎ��Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
				ex.printStackTrace();
			}

		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
			ex.printStackTrace();
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(candidate);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
			ex.printStackTrace();
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}
}
