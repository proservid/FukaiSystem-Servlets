package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.ProductNumber;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class NumCheck extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static final Logger lg = Logger.getLogger("A1");
	private static final String className = "NumCheck\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		ProductNumber input = null;
		StringBuilder err = new StringBuilder("");
		int result = -1;
		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof ProductNumber) {
					input = (ProductNumber)obj;
				} else {
					err.append(className + "readObject��String�^�ł͂���܂���\n");
					lg.error(className + "readObject��String�^�ł͂���܂���");
				}
			}

			try {
				ps = c.prepareStatement("SELECT 1 FROM T_����_�e WHERE ���ϊ�=? AND ���ϔԍ�=? AND ���ώ}��=?");
				ps.setInt(1, input.getPeriod());
				ps.setInt(2, input.getNumber());
				ps.setString(3, input.getBranch());
				rs = ps.executeQuery();
				if(rs.next()) {
					result += 1;
				}
				ps = c.prepareStatement("SELECT 1 FROM T_����_�e WHERE �����=? AND ����ԍ�=? AND ����}��=?");
				ps.setInt(1, input.getPeriod());
				ps.setInt(2, input.getNumber());
				ps.setString(3, input.getBranch());
				rs = ps.executeQuery();
				if(rs.next()) {
					result += 2;
				}
				result++;
			} catch(SQLException ex) {
				err.append("�e�[�u���uT_�e�[�u�����v�̓Ǎ��Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}

		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(result);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}
}
