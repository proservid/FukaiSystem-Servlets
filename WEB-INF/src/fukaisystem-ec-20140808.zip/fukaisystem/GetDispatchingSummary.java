package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.DispatchingDTO;
import fukaisystem.dto.OrderDocumentDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class GetDispatchingSummary extends GenericServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetDispatchingSummary\n";

	@Override
	public void service(ServletRequest request, ServletResponse response) {
		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		DispatchingDTO dispDTO = null;
		StringBuilder err = new StringBuilder();

		int id = 0;

		Vector<Vector<Object>> data = new Vector<Vector<Object>>();

		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof Number) {
					id = ((Number)obj).intValue();
				} else {
					err.append(className + "readObject��SetSummaryDTO�^�ł͂���܂���\n");
					lg.error(className + "readObject��SetSummaryDTO�^�ł͂���܂���");
				}
			}
			try {
				ps = c.prepareStatement("SELECT * FROM T_�o��_�q c" +
						" WHERE �o�ɐeID=?");
				ps.setInt(1, id);
				rs = ps.executeQuery();
				while(rs.next()) {
					Vector<Object> line = new Vector<Object>();
					line.add(rs.getInt("�啪��CD"));
					line.add(rs.getInt("������CD"));
					line.add(rs.getInt("������CD"));
					line.add(rs.getString("�i��"));
					line.add(rs.getBoolean("�eFLG"));
					line.add(rs.getDouble("����"));
					line.add(rs.getInt("���ʒP��CD"));
					line.add(rs.getDouble("�d�ʒ���"));
					line.add(rs.getInt("�P��"));
					line.add(rs.getInt("���z"));
					line.add(rs.getString("���l"));
					line.add(rs.getInt("�݌ɐeID"));
					line.add(rs.getInt("�݌ɎqID"));
					data.add(line);
				}


				ps = c.prepareStatement("SELECT * FROM T_�o��_�e p WHERE �o�ɐeID=?");
				ps.setInt(1, id);
				rs = ps.executeQuery();
				while(rs.next()) {
					dispDTO = new DispatchingDTO(
					 rs.getInt("�o�ɐeID"),
					 rs.getInt("�����"),
					 rs.getInt("����ԍ�"),
					 rs.getString("����}��"),
					 "","","",0,
					 rs.getString("�p�r"),
					 rs.getString("�E�v"),
					 data,
					 rs.getDate("�o�ɔN����"),
					 0,
					 0,
					 0,
					 false);
				}

			} catch(SQLException ex) {
				err.append(className + "DB�G���[���������܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(dispDTO);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}

}
