﻿package fukaisystem;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.dto.OrderDocumentDTO;
import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;


public class OrderRegistration extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static final Logger lg = Logger.getLogger("A1");
	private static final String className = "OrderRegistration\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		Statement st = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean isError = false;
		OrderDocumentDTO odd = null;
		String output = "";
		StringBuilder err = new StringBuilder("");
		int orderID = -1;
		Map<Integer, DeliverySlip> taxMap = null;

		try {

			/**
			 * クライアントデータ受け取り
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObjectがnullです\n");
				lg.error(className + "readObjectがnullです");
			} else {
				if(obj instanceof OrderDocumentDTO) {
					odd = (OrderDocumentDTO)obj;
				} else {
					err.append(className + "readObjectがString型ではありません\n");
					lg.error(className + "readObjectがString型ではありません");
				}
			}

			try {
				//コミット後でありさえすればよい。
				//コミット後ということは、子・孫ともども更新されているはずで、問題は生じない
				//親→子→孫（加工→材料）の順が守られている限り、デッドロックは発生しないはず
				st = c.createStatement();
				st.executeUpdate("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
				st.executeUpdate("BEGIN TRANSACTION");
//				st.executeQuery("SELECT COUNT(*) FROM T_在庫_親 WITH(TABLOCKX)");
//				st.executeQuery("SELECT COUNT(*) FROM T_在庫_子 WITH(TABLOCKX)");
			} catch(SQLException ex) {
				isError = true;
				err.append(className + "トランザクションの開始に失敗しました\n");
				Logging.logStackTrace(ex, lg, className);
			}

			orderID = odd.getInt(4);
			if(odd.getInt(1) * odd.getInt(2) == 0) {
				//注文期または注文番号を0に変更したということは、消去せよということ
				if(orderID != 0) {
					try {
						ps = c.prepareStatement("DELETE FROM T_在庫_親 WHERE ID=?");
						ps.setInt(1, orderID);
						ps.executeUpdate();
						ps = c.prepareStatement("DELETE FROM T_在庫_子 WHERE ID=?");
						ps.setInt(1, orderID);
						ps.executeUpdate();
						orderID = 0;
					} catch(SQLException ex) {
						isError = true;
						err.append(className + "在庫テーブルの削除に失敗しました\n");
						Logging.logStackTrace(ex, lg, className);
					}
				}
			} else {
				if(orderID == 0 || odd.getInt(3) == 0) {
					try {
						ps = c.prepareStatement(
								"INSERT INTO T_在庫_親" +
								" OUTPUT inserted.在庫親ID as newId, inserted.更新日" +
								" SELECT ?, ?, ?, MAX(伝票番号)+1, ?, ?, ?, ?, ?, ?,? FROM T_在庫_親");
						int i = 1;
						ps.setInt(i, odd.getInt(1)); i++;//注文期
						ps.setInt(i, odd.getInt(2)); i++;//注文番号
						ps.setString(i, odd.getStr(1)); i++;//注文枝番
//自動採番
//						ps.setInt(i, odd.getInt(3)); i++;//伝票番号
						ps.setInt(i, odd.getInt(0)); i++;//仕入先CD
						ps.setDate(i, odd.getDate(0)); i++;//注文年月日
						ps.setDate(i, odd.getDate(1)); i++;//指定納期
						ps.setString(i, odd.getStr(2)); i++;//摘要
						ps.setString(i, odd.getStr(3)); i++;//納入先指定
						ps.setTimestamp(i, new Timestamp(new java.util.Date().getTime())); i++;//更新日
						ps.setInt(i, 0); i++;//更新者CD
						boolean isResultSet = ps.execute();
						int   updateCount = 0;
						while (true) {
						   if (isResultSet) {
						         rs = ps.getResultSet();
						         while (rs.next()) {
						        	orderID = rs.getInt(1);
						            System.out.println("newId: " + rs.getInt(1) +
						                               "更新日: " + rs.getTimestamp(2));
						         }
						         rs.close();
						   }
						   else {
						         updateCount = ps.getUpdateCount();
						         if (updateCount == -1) {
						            break;
						         }
						   }
						   isResultSet = ps.getMoreResults();
						}
					} catch(SQLException ex) {
						isError = true;
						err.append(className + "テーブル「T_在庫_親」の更新に失敗しました\n");
						Logging.logStackTrace(ex, lg, className);
					}

				} else {
					try {
						ps = c.prepareStatement("UPDATE T_在庫_親 SET" +
							" 注文期=?, 注文番号=?, 注文枝番=?, 仕入先CD=?, 注文年月日=?, 指定納期=?," +
							" 摘要=?, 納入先指定=?, 更新日=?, 更新者CD=?" +
							" WHERE 在庫親ID=?");
						int i = 1;
						ps.setInt(i, odd.getInt(1)); i++;//注文期
						ps.setInt(i, odd.getInt(2)); i++;//注文番号
						ps.setString(i, odd.getStr(1)); i++;//注文枝番
//自動採番
//						ps.setInt(i, odd.getInt(3)); i++;//伝票番号
						ps.setInt(i, odd.getInt(0)); i++;//仕入先CD
						ps.setDate(i, odd.getDate(0)); i++;//注文年月日
						ps.setDate(i, odd.getDate(1)); i++;//指定納期
						ps.setString(i, odd.getStr(2)); i++;//摘要
						ps.setString(i, odd.getStr(3)); i++;//納入先指定
						ps.setTimestamp(i, new Timestamp(new java.util.Date().getTime())); i++;//更新日
						ps.setInt(i, 0); i++;//更新者CD
						ps.setInt(i, orderID); i++;//在庫親ID
						ps.executeUpdate();
						//子孫のデータ更新は、削除→追加にて
						ps = c.prepareStatement("DELETE FROM T_在庫_子 WHERE 在庫親ID=?");
						//where以降
						i = 1;
						ps.setInt(i, orderID);//在庫親ID
						ps.executeUpdate();
					} catch(SQLException ex) {
						isError = true;
						err.append(className + "在庫テーブルの削除に失敗しました\n");
						Logging.logStackTrace(ex, lg, className);
					}
				}

				int k = 1;
				try {
					ps = c.prepareStatement(
						"INSERT INTO T_在庫_子 VALUES(" +
						"?, ?, ?, ?, ?, ?, ?, ?, ?, ?," +
						"?, ?, ?, ?, ?, ?, ?)");
					taxMap = new HashMap<Integer, DeliverySlip>();
					System.out.println(odd.getVector(0));
					for(Vector<Object> v : odd.getVector(0)) {
						if(v.get(14) != null) {
							if(!taxMap.containsKey(v.get(14))) {
								taxMap.put((Integer)v.get(14), new DeliverySlip(v.get(15) == null ? null : new Date(((java.util.Date)v.get(15)).getTime()), v.get(16) == null ? 0 : (Integer)v.get(16)));
							}
						}
						int tag = (Integer)v.get(0);
						if(tag != 0) {
							int i = 1;
							int j = 0;
							ps.setInt(i, k); i++;//ID
							ps.setInt(i, orderID); i++;//親ID
							ps.setInt(i, (Integer)v.get(j)); i++; j++;//表示CD
							ps.setInt(i, (v.get(j) == null) ? 0 : (Integer)v.get(j)); i++; j++;//大分類CD
							ps.setInt(i, (v.get(j) == null) ? 0 : (Integer)v.get(j)); i++; j++;//中分類CD
							ps.setInt(i, (v.get(j) == null) ? 0 : (Integer)v.get(j)); i++; j++;//小分類CD
							ps.setString(i, (String)v.get(j)); i++; j++;//名称
							ps.setBoolean(i, (Boolean)v.get(j)); i++; j++;//各FLG
							ps.setInt(i, (Integer)v.get(j)); i++; j++;//数量
							ps.setInt(i, (Integer)v.get(j)); i++; j++;//数量単位CD
							ps.setDouble(i, (Double)v.get(j)); i++; j++;//重量長さ（単位を要検討のこと）
							ps.setInt(i, (Integer)v.get(j)); i++; j++;//単価
							ps.setInt(i, (Integer)v.get(j)); i++; j++;//金額
							ps.setString(i, (String)v.get(j)); i++; j++;//備考
							ps.setDate(i, v.get(j) == null ? null : new java.sql.Date(((java.util.Date)v.get(j)).getTime())); i++; j += 2;//入庫年月日
							ps.setDate(i, null); i++;//出庫年月日
							ps.setInt(i, v.get(j) == null ? 0 : (Integer)v.get(j));
							ps.addBatch();
							k++;
						}
					}
					int[] updateCounts = ps.executeBatch();
					lg.info("T_在庫_子は" + updateCounts.length + "件処理されました。");

					ps = c.prepareStatement(
					 "MERGE INTO T_指定納品書 AS t" +
					 " USING (SELECT ? AS ID, ? AS 納品書日, ? AS 消費税) AS w" +
					 "  ON t.ID=w.ID" +
					 " WHEN MATCHED THEN" +
					 "  UPDATE SET" +
					 "   t.ID = w.ID," +
					 "   t.納品書日 = w.納品書日," +
					 "   t.消費税 = w.消費税" +
					 " WHEN NOT MATCHED THEN" +
					 "  INSERT VALUES(w.ID, w.納品書日, w.消費税);");
					for(Map.Entry<Integer, DeliverySlip> e : taxMap.entrySet()) {
						System.out.println("key:"+e.getKey());System.out.println("value:"+e.getValue());
						ps.setInt(1, e.getKey());//ID
						ps.setDate(2, e.getValue().getDate());
						ps.setInt(3, e.getValue().getTax());//消費税
						ps.addBatch();
					}
					updateCounts = ps.executeBatch();
					lg.info("T_指定納品書は" + updateCounts.length + "件処理されました。");
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "テーブル「T_在庫_子」の更新に失敗しました\n");
					Logging.logStackTrace(ex, lg, className);
				}

				try {
					//注文書データで使用していない納品書番号は削除する
					ps = c.prepareStatement(
							"delete from T_指定納品書 where ID IN (" +
							"select ID from T_指定納品書 f WHERE NOT EXISTS(" +
							"SELECT 1 FROM T_在庫_子 c WHERE c.納品書番号=f.ID))");
					ps.executeUpdate();
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "指定納品書の掃除に失敗しました\n");
					Logging.logStackTrace(ex, lg, className);
				}

			}

			if(!isError) {
				try {
					st = c.createStatement();
					st.executeUpdate("COMMIT");
				} catch(SQLException ex) {
					isError = true;
					err.append(className + "コミットに失敗しました\n");
					Logging.logStackTrace(ex, lg, className);
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			isError = true;lg.debug("error");
			lg.error(ex);
		} finally {
			if(isError) {lg.debug("rollback");
				try{
					st = c.createStatement();
					st.executeUpdate("ROLLBACK");
				} catch(SQLException ex) {
					err.append(className + "ロールバックに失敗しました\n");
					Logging.logStackTrace(ex, lg, className);
				}
			}
		}

		/**
		 * クライアントに送信
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(orderID);
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}
	private class DeliverySlip {
		Date date;
		int tax;

		DeliverySlip(Date date, int tax) {
			this.date = date;
			this.tax = tax;
		}

		Date getDate() {
			return date;
		}
		int getTax() {
			return tax;
		}
	}
}
