/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fukaisystem.dto;

import java.io.Serializable;

/**
 *
 * @author kameura
 */
public class CandidateInputDTO implements Serializable {
	private String input;
	private boolean isSupplier, isValidOnly;
	public CandidateInputDTO(String input, boolean isSupplier, boolean isValidOnly) {
		this.input = input;
		this.isSupplier = isSupplier;
		this.isValidOnly = isValidOnly;
	}
	public String getInput() {
		return input;
	}
	public boolean isSupplier() {
		return isSupplier;
	}
	public boolean isValidOnly() {
		return isValidOnly;
	}
}
