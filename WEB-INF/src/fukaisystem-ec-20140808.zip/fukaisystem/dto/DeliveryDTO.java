/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fukaisystem.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Vector;

/**
 *
 * @author kameura
 */
public class DeliveryDTO implements Serializable {
	Date issue, shipping;
	int shippingID, productID, account, state, way, tax, discount, type;
	String note_s;
	Vector<Vector<Object>> vector;

	public DeliveryDTO(int shippingID, int productID, int account, Date issue, int state, int way, int tax, int discount, int type, String note_s, Vector<Vector<Object>> vector) {
		this.shippingID = shippingID;
		this.productID = productID;
		this.account = account;
		this.state = state;
		this.way = way;
		this.tax = tax;
		this.discount = discount;
		this.type = type;
		this.issue = issue;
		this.note_s = note_s;
		this.vector = vector;
	}

	public String getString() {
		return note_s;
	}

	public int getInt(int order) {
		int i = 0;
		switch(order) {
			case 0:
				i = shippingID; break;
			case 1:
				i = productID; break;
			case 2:
				i = account; break;
			case 3:
				i = state; break;
			case 4:
				i = way; break;
			case 5:
				i = tax; break;
			case 6:
				i = discount; break;
			case 7:
				i = type; break;

		}
		return i;
	}

	public Date getDate() {
		return issue;
	}

	public Vector<Vector<Object>> getVector() {
		return vector;
	}
}
