/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fukaisystem.dto;

import java.io.Serializable;
import java.sql.Date;
import java.util.Vector;

/**
 *
 * @author kameura
 */
public class SalesDTO implements Serializable {
	int deliveryID;
	int deliveryState;
	int deliveryWay;
	int slipNum;
	int type;
	Date salesDate;
	String note;
	Vector<Vector<Object>> child;

	public SalesDTO(int deliveryID, int deliveryState, int deliveryWay, int slipNum, int type,
		Date salesDate, String note, Vector<Vector<Object>> child) {
		this.deliveryID = deliveryID;
		this.deliveryState = deliveryState;
		this.deliveryWay = deliveryWay;
		this.slipNum = slipNum;
		this.type = type;
		this.salesDate = salesDate;
		this.note = note;
		this.child = child;
	}
	public String getString() {
		return note;
	}
	public int getInt(int order) {
		int i = 0;
		switch(order) {
			case  0: i = deliveryID; break;
			case  1: i = deliveryState; break;
			case  2: i = deliveryWay; break;
			case  3: i = slipNum; break;
			case  4: i = type; break;
		}
		return i;
	}
	public Date getDate() {
		return salesDate;
	}
	public Vector<Vector<Object>> getVector() {
		return child;
	}
	public void setVector(Vector<Vector<Object>> child) {
		this.child = child;
	}
}
