package fukaisystem.group;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

import fukaisystem.sql.DBConnection;
import fukaisystem.util.Logging;
import fukaisystem.dto.Banner;
import fukaisystem.dto.Repeat;
import fukaisystem.dto.Schedule;
import fukaisystem.dto.ScheduleDTO;

public class GetSchedule extends GenericServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static final Logger lg = Logger.getLogger("A1");
	private static final String className = "GetSchedule\n";

	public void service(ServletRequest request, ServletResponse response) {

		DBConnection dbc = new DBConnection();
		Connection c = dbc.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Date from = null;
		Date to = null;
		StringBuilder err = new StringBuilder("");
		List<Date> holidays = new ArrayList<Date>();
		Map<String, Schedule> map = new HashMap<String, Schedule>();

		try {

			/**
			 * �N���C�A���g�f�[�^�󂯎��
			 */
			ObjectInputStream in = new ObjectInputStream(request.getInputStream());
			Object obj = in.readObject();
			in.close();

			if(obj == null) {
				err.append(className + "readObject��null�ł�\n");
				lg.error(className + "readObject��null�ł�");
			} else {
				if(obj instanceof Date) {
					from = (Date)obj;
					Calendar cal = Calendar.getInstance();
					cal.setTime(from);
					cal.add(Calendar.DATE, 7);
					to = new Date(cal.getTimeInMillis());
				} else {
					err.append(className + "readObject��String�^�ł͂���܂���\n");
					lg.error(className + "readObject��String�^�ł͂���܂���");
				}
			}

			try {
				ps = c.prepareStatement("SELECT * FROM T_�j�� WHERE �j��>=? and �j��<?");
				ps.setDate(1, from);
				ps.setDate(2, to);
				rs = ps.executeQuery();
				while(rs.next()) {
					holidays.add(rs.getDate("�j��"));
				}

				ps = c.prepareStatement("SELECT * FROM T_�\�� WHERE �N����>=? and �N����<? order by �l��CD,�N����");
				ps.setDate(1, from);
				ps.setDate(2, to);
				rs = ps.executeQuery();
				while(rs.next()) {
					String cd = rs.getString("�l��CD");
					String contents = rs.getString("���e");
					if(map.containsKey(cd)) {
						Map<Date, String> innerMap = map.get(cd).getText();
						Date d = rs.getDate("�N����");
						if(innerMap.containsKey(d)) {
							//�d������͂��͂Ȃ�
						} else {
							innerMap.put(d, contents);
						}
					} else {
						Map<Date, String> innerMap = new HashMap<Date, String>();
						innerMap.put(rs.getDate("�N����"), contents);
						map.put(cd, new Schedule(innerMap, null, null));
					}
				}
				//�J�n�������T�܂��͏I���������T�܂��͊J�n������T�ȑO���I���������T�ȍ~
				ps = c.prepareStatement("SELECT * FROM T_�o�i�[ WHERE (�J�n��>=? and �J�n��<?) or (�I����>=? and �I����<?) or (�J�n��<? and �I����>?) order by �l��CD,�J�n��,�I����");
				ps.setDate(1, from);
				ps.setDate(2, to);
				ps.setDate(3, from);
				ps.setDate(4, to);
				ps.setDate(5, from);
				ps.setDate(6, to);
				rs = ps.executeQuery();
				while(rs.next()) {
					String cd = rs.getString("�l��CD");
					if(map.containsKey(cd)) {
						Schedule schedule = map.get(cd);
						List<Banner> banners = schedule.getBanners();
						if(banners == null) banners = new ArrayList<Banner>();
						banners.add(new Banner(rs.getInt("ID"), rs.getDate("�J�n��"), rs.getDate("�I����"), rs.getString("���e")));
						schedule.setBanners(banners);
					} else {
						List<Banner> banners = new ArrayList<Banner>();
						banners.add(new Banner(rs.getInt("ID"), rs.getDate("�J�n��"), rs.getDate("�I����"), rs.getString("���e")));
						map.put(cd, new Schedule(null, banners, null));
					}
				}

				ps = c.prepareStatement("SELECT * FROM T_�J��Ԃ� order by �l��CD");
				rs = ps.executeQuery();
				while(rs.next()) {
					String cd = rs.getString("�l��CD");
					if(map.containsKey(cd)) {
						Schedule schedule = map.get(cd);
						List<Repeat> repeats = schedule.getRepeats();
						if(repeats == null) repeats = new ArrayList<Repeat>();
						repeats.add(new Repeat(rs.getBoolean("�j������FLG"), rs.getInt("����"), rs.getString("���e")));
						schedule.setRepeats(repeats);
					} else {
						List<Repeat> repeats = new ArrayList<Repeat>();
						repeats.add(new Repeat(rs.getBoolean("�j������FLG"), rs.getInt("����"), rs.getString("���e")));
						map.put(cd, new Schedule(null, null, repeats));
					}
				}
			} catch(SQLException ex) {
				err.append("�e�[�u���uT_�e�[�u�����v�̓Ǎ��Ɏ��s���܂���\n");
				Logging.logStackTrace(ex, lg, className);
			}

		} catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		}

		/**
		 * �N���C�A���g�ɑ��M
		 */
		try {
			response.setContentType("application/octet-stream");
			ObjectOutputStream out = new ObjectOutputStream(response.getOutputStream());
			out.writeObject(new ScheduleDTO(map, holidays));
			out.writeUTF(err.toString());
			out.flush();
			out.close();
		}catch(Exception ex) {
			Logging.logStackTrace(ex, lg, className);
		} finally {
			try {
				if(c != null && !c.isClosed()) c.close();
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
// The following processes requires JDBC4.0.
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
					lg.debug(className + "ps is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
			try {
				if(rs != null && !rs.isClosed()) {
					rs.close();
					lg.debug(className + "rs is closed by jdbc4.0");
				}
			} catch(SQLException ex) {
				Logging.logStackTrace(ex, lg, className);
			}
		}
	}
}
